# Concrete root handoff

The proposed overlay is `public/`, containing `audit/formal/lean-prefix-mgw-mean/` and `audit/evidence/prefix-mgw-mean-formal-verification-2026-09-08/`. Only this ignored lane was written. The earlier semantic review, accepted candidate, stopped campaign and pending dependency proposals remain unchanged. This is a completed bounded source unit; public execution/adoption/publication remains separate work.

## Read and adopt exact source scope

1. Read `PACKAGING_REVIEW.md`, `PRIVATE_LOCATORS.json`, `CONTROL_REUSE_INVENTORY.json`, final manifests and static results. Inspect the new 390-line adapter, complete target/source graph and actual historical acceptance projections. The selected proof remains SHA `17fc2d8fce5ad0ba28cc8348e9348911c393e6eb00515c8139fbd27b85331b6a`; mean acceptance remains `26789c336a5928a07786bc2e1867f600995c09300a1e9b056083349a2fce3fb2`.
2. Choose/adopt the explicit 24-module snapshot ownership. Its source closure is portable without adopting separate pending generic/MGW/probability directory paths first. Their 8/11/6 packages still require their own promised adapters/replays if those units are published. Preserve existing DNF13 status and already accepted first-import-line transports.
3. Review private/public projection mapping and the historical archive. The package includes all 21 v2 attempt results/source variants/registered compiler commands/bounded streams and the failed expired v1 evidence pinned by the prior-terminal record. Original raw reports and absolute paths stay in ignored buffers/inventory; public copies have their own hashes. Compiled objects and every binary input are not redistributed.
4. Reconcile only current global source/catalog/result/claim prose after actual public replay. The supplied exposition opening already distinguishes accepted local mean3 from unexecuted public packaging. Its mathematical text and the retained-rank SVG were reused unchanged. Closed originals must remain sealed.

## New adapter gates before execution credit

The proposed manifest is `public/audit/formal/lean-prefix-mgw-mean/replay-proposed-v1.json`. Its exact final digest is recorded in this lane's final seal. It binds 48 formal payload files, including the new adapter and two deliberately non-live registration/control-adoption templates.

Freeze a new controls registration and scope the required controls to actual changed call sites. Reuse the original exact source-policy/parser vectors, miniature reporter mutations, runtime operational evidence and applicable finalization cases from `CONTROL_REUSE_INVENTORY.json`; do not claim that old AST fragment tests cover this new whole entrypoint. No executable new controls harness is supplied or run by this source proposal. Implement/adapt that bounded harness, preserve its actual inputs/failures/results, inspect them, then write an actual `CONTROLS_ACCEPTANCE.json` bound to the exact adapter/manifest. The proposed production adapter refuses execution without that separate digest.

Resolve aggregate timing explicitly. The existing helper Git preflight is bounded per query, but its timeouts are not clamped to the new stage. The runtime hashes Lean inputs after the caller's deadline check and before spawning. The proposal requires an external stage supervisor plus actual delayed-preflight/registration/launch/closure controls. Alternatively revise an explicit runtime hook in a new preserved source revision and test the changed guards. Do not advertise a hard aggregate cap from the caller checks alone.

Only after these controls, register the proposed 120-minute/six-invocation production stage with one owner and shared normal/O ledger. Run the five commands in the portable replay design: selected normal/O, cosmetic normal/O, and actual same-selected-source wrong-final-target. Expect 25 compiler/kernel children plus one named probe for each positive, and 23 compiler children plus one probe for the negative. Four positive arrays must match exact mean3/MGW11/probability6 records; negative must reach the actual final raw/alias mismatch. Preserve a new packaging receipt, complete rehash and STOP. This does not reopen any old campaign.

## Source-only command already used here

```text
python3 -I -S -B .local/sx-mean-public-packaging-source-20260908/static_review.py
```

It reads and hashes sources, parses Python AST/JSON/XML and checks portable links; it imports no runtime/adapter and invokes no Lean, kernel, replay, numerical or visual program. The private source build scripts only copy/project bytes. Source-only passes are not substitute controls or formal execution.

## Coherent public milestone after actual replay

Add precise reader links to `audit/formal/LEAN_4_33_FREEZE_AND_REPLAY.md` and the current mathematical result guide, one scoped method-catalog formal-assurance entry or explicit existing-entry update after schema review, regenerated `METHODS.md`, and a professional changelog note. State three mean results, with inherited families and pending statistical/executable scope kept explicit. Do not append all copied dependencies to a new-proof count or silently update broader Program A–E/application claims.

Run the applicable method catalog, mathematical source/publication, Lean source/replay identity, documentation and repository coherence gates under root's current policy. Keep aggregate Lean baseline proof counts unchanged unless its own graph is actually changed. Root owns public writes, professional unsigned commits and hosted/mainline integration; this lane supplies no Git action or hosted result.

Build Markdown/PDF and render/review the SVG under a separately registered publication stage with current style, links, fonts, extraction and visual gates. These checks have not occurred here. No public-ready, remote-main, estimator-calibration or scientific-priority claim follows from this source-only milestone.
