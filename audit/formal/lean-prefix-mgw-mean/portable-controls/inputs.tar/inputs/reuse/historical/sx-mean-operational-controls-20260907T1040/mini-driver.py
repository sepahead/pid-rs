"""Operational miniature for the exact reporter; zero probability theorem credit."""
from __future__ import annotations
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import sys
from types import ModuleType

LANE = Path(__file__).resolve().parent
ROOT = LANE.parent.parent
PREP = LANE.parent / 'sx-prefix-mgw-mean-type-preparation-20260906'
PASSED = PREP / 'runs/full-normal-01'


def main():
    if not (sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode and sys.flags.optimize in (0, 1)):
        raise RuntimeError('requires Python -I -S -B, optionally -O')
    freeze_raw = (LANE / 'CONTROL_INPUT_FREEZE.json').read_bytes()
    freeze = json.loads(freeze_raw)
    modules = {}
    for name, sha in freeze['files'].items():
        raw = (LANE / name).read_bytes()
        if hashlib.sha256(raw).hexdigest() != sha:
            raise RuntimeError('mini input changed: ' + name)
        if name in ('runtime.py', 'policy.py'):
            module = ModuleType('mini_' + name[:-3]); module.__file__ = str(LANE / name)
            exec(compile(raw, str(LANE / name), 'exec', dont_inherit=True, optimize=sys.flags.optimize), module.__dict__)
            modules[name] = module
    j, policy = modules['runtime.py'], modules['policy.py']
    lock = (LANE / 'MINI_EXECUTION.lock').open('a+')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    registration = j.strict_json((LANE / 'REGISTRATION.json').read_bytes())
    deadline = datetime.datetime.fromisoformat(registration['deadline_utc'])
    j.require(datetime.datetime.now(datetime.timezone.utc) < deadline, 'mini deadline exhausted')
    ledger_path = LANE / 'EXECUTION_LEDGER.jsonl'
    events = [j.strict_json(line.encode()) for line in ledger_path.read_text().splitlines()]
    registered_children = [item for item in events if item['event'] == 'child_registered']
    output = LANE / ('mini-output-' + str(sys.flags.optimize) + '-' + str(len(registered_children)))
    output.mkdir(exist_ok=False)
    snapshot = j.Snapshot(); runner = None
    result = {'status': 'failed', 'scope': 'Synthetic three-site reporter only; zero terminal law proofs. Miniature imports differ from the separate full candidate grammar fixture.',
              'mode': sys.flags.optimize, 'registered_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (output / 'REGISTERED.json').write_bytes(j.canonical(result))
    try:
        j.require(snapshot.read(LANE / 'CONTROL_INPUT_FREEZE.json') == freeze_raw, 'mini freeze changed after loading')
        for name, sha in freeze['files'].items():
            j.require(j.digest(snapshot.read(LANE / name)) == sha, 'captured mini input changed: ' + name)
        j.verify_source_pins(ROOT, snapshot)
        _, base = j.load_helpers(ROOT, snapshot)
        base.check_toolchain(); base.check_lakefile(); base.check_manifest()
        base.check_dependency_checkouts(base.find_git())
        old_raw = snapshot.read(PASSED / 'receipt.json')
        j.require(j.digest(old_raw) == 'edb2bd4bcb92c25276367a80b7a462c02cc8977163825f9314359e74450f0338', 'preparation receipt changed')
        old = j.strict_json(old_raw)
        env_raw = snapshot.read(PASSED / 'environment.json')
        j.require(j.digest(env_raw) == old['artifacts']['environment.json'], 'environment changed')
        observed = j.strict_json(env_raw)
        for name, sha in observed['tools'].items():
            j.require(j.digest(snapshot.read(Path(name))) == sha, 'tool changed')
        lean = next(Path(n) for n in observed['tools'] if n.endswith('/bin/lean'))
        checker = next(Path(n) for n in observed['tools'] if n.endswith('/bin/leanchecker'))
        deps = ['PidFiniteConvergence/Deterministic', 'PidFiniteConvergence/SxEventBridge',
                'MgwBridgeDepsV1/SxDnf/Contract', 'MgwBridgeDepsV1/JoinLog/Contract',
                'MgwBridgeDepsV1/SxDnf/JudgeCore', 'PidMgwBridge/Contract']
        src, build = output / 'src', output / 'build'; src.mkdir(); build.mkdir()
        for module in deps:
            source_raw = snapshot.read(PREP / 'sources' / (module + '.lean'))
            captured_source = snapshot.read(PASSED / 'src' / (module + '.lean'))
            j.require(j.digest(captured_source) == old['artifacts']['src/' + module + '.lean'], 'dependency source capture differs from receipt')
            j.require(source_raw == captured_source, 'dependency source mismatch')
            raw = snapshot.read(PASSED / 'build' / (module + '.olean'))
            j.require(j.digest(raw) == old['artifacts']['build/' + module + '.olean'], 'dependency object mismatch')
            target = build / (module + '.olean'); target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw); snapshot.read(target)
        header = 'set_option autoImplicit false\nset_option warningAsError true\nuniverse u v w\n'
        targets = ['∀ (A : Type u) (B : Type v) (C : Type w), A → B → C → (' + str(i+1) + ' : Nat) = ' + str(i+1) for i in range(3)]
        mock = header + 'namespace PidPrefixMgwMeanCandidate\n'
        for index, name in enumerate(policy.THEOREMS):
            target = targets[index]
            mock += f'private theorem proof_{index} : {target} := by\n  intro _ _ _ _ _ _\n  rfl\n'
        for index, name in enumerate(policy.THEOREMS):
            mock += f'theorem {name} : {targets[index]} := @proof_{index}\n'
        mock += 'end PidPrefixMgwMeanCandidate\n'
        data = {'PidPrefixMgwMean/Candidate': mock}
        for family in ('RawTargets', 'AliasTargets'):
            text = header + f'namespace PidPrefixMgwMean{family}\n'
            for index, name in enumerate(policy.THEOREMS): text += f'def {name} : Prop := {targets[index]}\n'
            text += f'end PidPrefixMgwMean{family}\n'
            data['PidPrefixMgwMean/' + family] = text
        data['PidPrefixMgwMean/SemanticJudge'] = snapshot.read(LANE / 'SemanticJudge.lean.in').decode()
        data['MeanReporterMiniRoot'] = 'import PidPrefixMgwMean.SemanticJudge\n'
        for module, text in data.items():
            q = src / (module + '.lean'); q.parent.mkdir(parents=True, exist_ok=True)
            q.write_text(text); snapshot.read(q)
        environment = {'PATH': str(lean.parent) + ':/usr/bin:/bin', 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8',
                       'LEAN_PATH': str(build) + os.pathsep + os.pathsep.join(observed['lean_search_path'].split(os.pathsep)[1:]),
                       'LEAN_SRC_PATH': str(src)}
        runner = j.Runner(output, environment, preparation=False)
        def execute(label, command, allow=False):
            snapshot.verify()
            j.require(not (LANE / 'STOP_RECORD.json').exists(), 'operational stage stopped')
            remaining = (deadline - datetime.datetime.now(datetime.timezone.utc)).total_seconds()
            j.require(remaining > 0, 'operational deadline exhausted')
            events = [j.strict_json(line.encode()) for line in ledger_path.read_text().splitlines()]
            used = sum(item['event'] == 'child_registered' for item in events)
            j.require(used < registration['max_compiler_kernel_children'], 'operational child budget exhausted')
            entry = {'event': 'child_registered', 'ordinal': used + 1,
                     'registered_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                     'command': command, 'label': label, 'output': str(output.relative_to(LANE)),
                     'mode': sys.flags.optimize, 'freeze_sha256': j.digest(freeze_raw)}
            with ledger_path.open('a') as stream:
                stream.write(json.dumps(entry, sort_keys=True) + '\n'); stream.flush(); os.fsync(stream.fileno())
            before_commands = len(runner.commands)
            try:
                return runner.run(command, src, label, timeout=min(600, remaining), allow_stdout=allow)
            finally:
                own_receipt = (runner.commands[-1] if len(runner.commands) == before_commands + 1
                               and runner.commands[-1].get('command') == command else None)
                terminal = {'event': 'child_terminal_observation', 'ordinal': used + 1,
                            'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                            'command_receipt': own_receipt,
                            'receipt_scope': 'actual current child' if own_receipt is not None else
                                             'no matching receipt available for this child'}
                with ledger_path.open('a') as stream:
                    stream.write(json.dumps(terminal, sort_keys=True) + '\n'); stream.flush(); os.fsync(stream.fileno())
        def compile_module(module):
            target = build / (module + '.olean'); target.parent.mkdir(parents=True, exist_ok=True)
            stdout = execute('compile-' + module.replace('/', '-'),
                             [str(lean), '-t', '0', '-M', '4096', '-o', str(target), str(src / (module + '.lean'))],
                             module.endswith('SemanticJudge'))
            snapshot.read(target)
            return stdout
        for module in data:
            stdout = compile_module(module)
            if module.endswith('SemanticJudge'): result['synthetic_semantic_records'] = policy.semantic_records(stdout, j.strict_json)
        execute('fresh-mini-kernel', [str(checker), '--fresh', 'MeanReporterMiniRoot'])
        result['positive'] = 'synthetic_fresh_reporter_pass'
        # A separate source/build graph preserves the successful graph byte-for-byte.
        negative_src, negative_build = output / 'negative-src', output / 'negative-build'
        negative_src.mkdir(); negative_build.mkdir()
        for q in sorted(src.rglob('*.lean')):
            dest = negative_src / q.relative_to(src); dest.parent.mkdir(parents=True, exist_ok=True)
            text = q.read_text()
            if q.relative_to(src).as_posix() == 'PidPrefixMgwMean/Candidate.lean':
                marker = 'theorem prefix_expectations_to_mgw_mean'
                text = text[:text.index(marker)] + 'theorem prefix_expectations_to_mgw_mean : True := by trivial\nend PidPrefixMgwMeanCandidate\n'
            dest.write_text(text); snapshot.read(dest)
        for q in sorted(build.rglob('*.olean')):
            relative = q.relative_to(build)
            if relative.as_posix() in ('PidPrefixMgwMean/Candidate.olean', 'PidPrefixMgwMean/SemanticJudge.olean', 'MeanReporterMiniRoot.olean'): continue
            dest = negative_build / relative; dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(snapshot.read(q)); snapshot.read(dest)
        # Root-owned runner keeps one command list; only its clean environment/cwd changes.
        src, build = negative_src, negative_build
        runner.environment['LEAN_PATH'] = str(build) + os.pathsep + os.pathsep.join(observed['lean_search_path'].split(os.pathsep)[1:])
        runner.environment['LEAN_SRC_PATH'] = str(src)
        compile_module('PidPrefixMgwMean/Candidate')
        before_negative_commands = len(runner.commands)
        try:
            compile_module('PidPrefixMgwMean/SemanticJudge')
        except j.JudgeError:
            if len(runner.commands) == before_negative_commands:
                raise
            cmd = runner.commands[-1]
            out = output / (str(len(runner.commands)-1).zfill(2) + '-' + cmd['label']) / 'stdout.log'
            text = out.read_text()
            j.require(cmd['failure'] is None and cmd['returncode'] != 0 and 'prefix_expectations_to_mgw_mean' in text and 'type mismatch' in text.lower(), 'wrong-target failed for another reason')
            result['negative'] = 'expected_final_type_rejection'
        else: raise RuntimeError('wrong-target miniature accepted')
        snapshot.verify()
        j.require(not (LANE / 'STOP_RECORD.json').exists(), 'operational stage stopped before closure')
        j.require(datetime.datetime.now(datetime.timezone.utc) < deadline, 'deadline before closure')
        result['status'] = 'operational_miniature_pass'
    except BaseException as error:
        result.update(status='failed', failure=str(error))
    finally:
        result['commands'] = [] if runner is None else runner.commands
        result['inputs'] = snapshot.manifest()
        try:
            snapshot.save(output)
            result['artifacts'] = {str(q.relative_to(output)): {'bytes': len(q.read_bytes()), 'sha256': j.digest(q.read_bytes())}
                                   for q in sorted(output.rglob('*')) if q.is_file()}
        except BaseException as error: result.update(status='failed', preservation_failure=str(error))
        try:
            snapshot.verify()
            j.require(not (LANE / 'STOP_RECORD.json').exists(),
                      'operational stage stopped during final evidence preservation')
            completed = datetime.datetime.now(datetime.timezone.utc)
            j.require(completed < deadline, 'operational deadline during final evidence preservation')
        except BaseException as error:
            result.update(status='failed', final_custody_failure=str(error))
        result['completed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        (output / 'RESULT.json').write_bytes(j.canonical(result))
        print(j.canonical({'status': result['status'], 'output': str(output)}).decode(), end='')
    return 0 if result['status'] == 'operational_miniature_pass' else 1

if __name__ == '__main__':
    raise SystemExit(main())
