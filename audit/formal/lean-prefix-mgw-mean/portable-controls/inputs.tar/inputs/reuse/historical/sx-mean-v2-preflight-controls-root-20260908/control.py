"""Exact preflight AST, real Snapshot, synthetic registration: zero Lean children."""
import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import sys
from types import ModuleType

LANE = Path(__file__).resolve().parent
REG = json.loads((LANE / 'REGISTRATION.json').read_bytes())
DEADLINE = datetime.datetime.fromisoformat(REG['deadline_utc'])
INPUTS = json.loads((LANE / 'INPUTS.json').read_bytes())
SOURCE = Path(INPUTS['source_lane'])

def now():
    return datetime.datetime.now(datetime.timezone.utc)

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def canonical(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()

def write(path, value):
    path.write_bytes(canonical(value))

require(sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
        and sys.flags.optimize in (0, 1), 'required Python flags')
require(now() < DEADLINE, 'control clock expired')
for name, expected in INPUTS['sha256'].items():
    require(digest((LANE / name).read_bytes()) == expected, 'input changed: ' + name)
freeze = json.loads((LANE / 'CONTROL_FREEZE.json').read_bytes())
require(digest(Path(__file__).read_bytes()) == freeze['control_sha256'], 'control source changed')
driver = ModuleType('source_only_preflight_driver')
driver.__file__ = str(LANE / 'campaign.py')
raw = (LANE / 'campaign.py').read_bytes()
exec(compile(raw, driver.__file__, 'exec', dont_inherit=True), driver.__dict__)
j = driver.load_module('unchanged_runtime', LANE / 'runtime.py', driver.RUNTIME_SHA)
tree = ast.parse(raw)
main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
start = next(i for i, n in enumerate(main.body) if isinstance(n, ast.Assign)
             and any(isinstance(t, ast.Name) and t.id == 'freeze_raw' for t in n.targets))
stop = next(i for i, n in enumerate(main.body) if isinstance(n, ast.Assign)
            and any(isinstance(t, ast.Name) and t.id == 'policy' for t in n.targets))
fragment = ast.Module(body=main.body[start:stop], type_ignores=[])
code = compile(ast.fix_missing_locations(fragment), 'actual-driver-preflight-before-policy', 'exec',
               optimize=sys.flags.optimize)
out = LANE / ('mode-' + str(sys.flags.optimize))
out.mkdir()
(out / 'executed-preflight.ast.txt').write_text(ast.dump(fragment, include_attributes=False))
records = []
prior = json.loads((SOURCE / 'PRIOR_CAMPAIGN_TERMINAL.json').read_bytes())
cases = [
    ('valid-v2', None),
    ('v1-freeze', 'mean judge is not an adopted'),
    ('v1-campaign', 'campaign schema differs'),
    ('development-80', 'fixed future campaign bound differs'),
    ('development-float', 'fixed future campaign bound differs'),
    ('development-bool', 'fixed future campaign bound differs'),
    ('full-9', 'fixed future campaign bound differs'),
    ('concurrency-2', 'fixed future campaign bound differs'),
    ('duration-120', 'campaign clock is not'),
    ('duration-719', 'campaign clock is not'),
    ('duration-721', 'campaign clock is not'),
    ('naive-clock', 'campaign clock is not'),
    ('future-clock', 'campaign clock is not'),
    ('expired-clock', 'campaign deadline exhausted'),
    ('stop-record', 'campaign is stopped'),
    ('freeze-digest', 'campaign freeze differs'),
    ('candidate-scope', 'candidate write scope differs'),
    ('missing-required-pin', 'required wrapper/source/adoption pins absent'),
    ('prior-record-drift', 'prior terminal campaign boundary differs'),
    ('prior-record-missing', 'PRIOR_CAMPAIGN_TERMINAL.json'),
    ('selection-digest', 'selection rule differs'),
    ('controls-not-adopted', 'wrapper controls lack completed adoption'),
    ('post-capture-prior-drift', 'input changed after capture'),
    ('prior-symlink', 'noncanonical or symlink input'),
    ('prior-hardlink', 'input must be a regular single-link file'),
] + [('prior-byte-drift-' + str(i), 'prior terminal preimage differs: ' + name)
     for i, name in enumerate(prior['files'])]
terminal = {'status': 'failed', 'mode': sys.flags.optimize,
            'scope': REG['scope'], 'records': records, 'compiler_kernel_children': 0}
try:
    for label, expected_error in cases:
        require(now() < DEADLINE, 'deadline before case')
        case = out / label
        case.mkdir()
        for name in driver.REQUIRED_WRAPPER_FILES:
            p = case / name
            p.parent.mkdir(parents=True, exist_ok=True)
            if name == 'OPERATIONAL_CONTROL_ACCEPTANCE.json':
                write(p, {'status': 'adopted_completed_operational_controls',
                          'new_mean_theorems_proved': 0, 'synthetic_control_only': True})
            else:
                p.write_bytes((SOURCE / name).read_bytes())
        for name in prior['files']:
            p = case / 'previous-terminal' / name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes((SOURCE / 'previous-terminal' / name).read_bytes())
        task_start = now() - datetime.timedelta(minutes=1)
        task = {'schema': 'pid-rs/prefix-mgw-mean-proof-campaign-v2',
                'max_development_attempts': 79, 'max_full_attempts': 8,
                'max_concurrent_wrappers': 1, 'candidate_write_scope': 'candidate/Candidate.lean',
                'registered_utc': task_start.isoformat(),
                'deadline_utc': (task_start + datetime.timedelta(minutes=720)).isoformat(),
                'selection_rule_sha256': digest((case / 'SELECTION_RULE.json').read_bytes())}
        body = {'schema': 'pid-rs/prefix-mgw-mean-proof-judge-freeze-v2',
                'status': 'adopted_after_actual_controls_before_candidate', 'candidate_exists': False,
                'preparation_sha256': json.loads((SOURCE / 'PREPARATION_INPUT_PINS.json').read_bytes())}
        if label == 'v1-freeze': body['schema'] = body['schema'].replace('-v2', '-v1')
        if label == 'v1-campaign': task['schema'] = task['schema'].replace('-v2', '-v1')
        for case_name, key, value in [
            ('development-80', 'max_development_attempts', 80),
            ('development-float', 'max_development_attempts', 79.0),
            ('development-bool', 'max_development_attempts', True),
            ('full-9', 'max_full_attempts', 9),
            ('concurrency-2', 'max_concurrent_wrappers', 2),
            ('candidate-scope', 'candidate_write_scope', 'elsewhere.lean')]:
            if label == case_name: task[key] = value
        if label.startswith('duration-'):
            task['deadline_utc'] = (task_start + datetime.timedelta(
                minutes=int(label.split('-')[1]))).isoformat()
        if label == 'naive-clock':
            task['registered_utc'] = task_start.replace(tzinfo=None).isoformat()
            task['deadline_utc'] = (task_start + datetime.timedelta(minutes=720)).replace(tzinfo=None).isoformat()
        if label in ('future-clock', 'expired-clock'):
            offset = 60 if label == 'future-clock' else -721
            shifted = now() + datetime.timedelta(minutes=offset)
            task['registered_utc'] = shifted.isoformat()
            task['deadline_utc'] = (shifted + datetime.timedelta(minutes=720)).isoformat()
        if label == 'stop-record': write(case / 'STOP_RECORD.json', {'synthetic': True})
        if label == 'prior-record-drift':
            changed = dict(prior); changed['actual_development_attempts'] = 0
            write(case / 'PRIOR_CAMPAIGN_TERMINAL.json', changed)
        if label == 'selection-digest':
            with (case / 'SELECTION_RULE.json').open('ab') as stream: stream.write(b'\n')
        if label == 'controls-not-adopted':
            write(case / 'OPERATIONAL_CONTROL_ACCEPTANCE.json', {'status': 'proposed', 'new_mean_theorems_proved': 0})
        body['wrapper_sha256'] = {name: digest((case / name).read_bytes())
                                  for name in sorted(driver.REQUIRED_WRAPPER_FILES)}
        if label == 'missing-required-pin': del body['wrapper_sha256']['PRIOR_CAMPAIGN_TERMINAL.json']
        if label == 'prior-record-missing': (case / 'PRIOR_CAMPAIGN_TERMINAL.json').unlink()
        if label.startswith('prior-byte-drift-'):
            name = list(prior['files'])[int(label.rsplit('-', 1)[1])]
            p = case / 'previous-terminal' / name
            value = p.read_bytes(); p.write_bytes(bytes([value[0] ^ 1]) + value[1:])
        historical = case / 'previous-terminal' / next(iter(prior['files']))
        if label in ('prior-symlink', 'prior-hardlink'):
            value = historical.read_bytes(); historical.unlink()
            target = case / 'retained-target'; target.write_bytes(value)
            if label == 'prior-symlink': historical.symlink_to(target)
            else: os.link(target, historical)
        write(case / 'FROZEN.json', body)
        task['freeze_sha256'] = digest((case / 'FROZEN.json').read_bytes())
        if label == 'freeze-digest': task['freeze_sha256'] = '0' * 64
        write(case / 'CAMPAIGN.json', task)
        snapshot = j.Snapshot()
        scope = dict(driver.__dict__)
        scope.update(LANE=case, PREP=SOURCE.parent / 'sx-prefix-mgw-mean-type-preparation-20260906',
                     snapshot=snapshot, j=j)
        error = None; reached = False
        try:
            exec(code, scope)
            reached = True
            require(all(str((case / 'previous-terminal' / name).absolute()) in snapshot.inputs
                        for name in prior['files']), 'not all prior bytes captured')
            if label == 'post-capture-prior-drift':
                value = historical.read_bytes()
                historical.write_bytes(bytes([value[0] ^ 1]) + value[1:])
            snapshot.verify()
        except Exception as exc:
            error = type(exc).__name__ + ': ' + str(exc)
        snapshot.save(case)
        write(case / 'CAPTURED_INPUTS.json', snapshot.manifest())
        record = {'name': label, 'expected_error': expected_error, 'actual_error': error,
                  'reached_pre_policy_sentinel': reached, 'captured_files': len(snapshot.inputs)}
        write(case / 'RESULT.json', record)
        records.append(record)
        require((error is None if expected_error is None else
                 error is not None and expected_error in error), 'unexpected outcome: ' + label)
        require(not (case / 'candidate').exists() and not (case / 'attempts').exists(),
                'control entered candidate execution')
    require(now() < DEADLINE, 'deadline after cases')
    terminal['status'] = 'passed'
except BaseException as exc:
    terminal['failure'] = repr(exc)
finally:
    terminal['completed_utc'] = now().isoformat()
    terminal['artifacts'] = {str(p.relative_to(out)): {'bytes': p.stat().st_size,
                             'sha256': digest(p.read_bytes())}
                             for p in sorted(out.rglob('*')) if p.is_file() and not p.is_symlink()}
    if now() >= DEADLINE: terminal.update(status='failed', deadline_exhausted=True)
    write(out / 'RESULT.json', terminal)
    print(json.dumps({'status': terminal['status'], 'cases': len(records), 'failure': terminal.get('failure')}))
raise SystemExit(0 if terminal['status'] == 'passed' else 1)
