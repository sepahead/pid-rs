"""Bounded entrypoint refusals and exact final-body causal controls; no Lean child."""
import ast
import contextlib
import datetime as dt
import hashlib
import io
import json
import pathlib
import stat
import subprocess
import sys
import types

LANE = pathlib.Path(__file__).resolve().parent
DEADLINE = dt.datetime.fromisoformat('2026-09-07T16:29:32.432599+00:00')
def now():
    return dt.datetime.now(dt.timezone.utc)
def require(ok, message):
    if not ok:
        raise RuntimeError(message)
def digest(raw):
    return hashlib.sha256(raw).hexdigest()
def canonical(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()

require(sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode, 'Python flags')
require(now() < DEADLINE, 'original deadline expired')
source = (LANE / 'campaign.py').read_bytes()
require(digest(source) == '914177695ebde982a154025ee0df6f497d3cd02c1317be3a96b79d57f59cf706', 'driver differs')
runtime = (LANE / 'runtime.py').read_bytes()
require(digest(runtime) == 'bd8a9f2272a20422863c9902ce2148d2957471bb958d13949fece923cb6a7f5d', 'runtime differs')
output = LANE / ('entrypoint-supplement-' + str(sys.flags.optimize))
output.mkdir()
(output / 'campaign.py.txt').write_bytes(source)
(output / 'runtime.py.txt').write_bytes(runtime)
(output / 'control.py.txt').write_bytes(pathlib.Path(__file__).read_bytes())
records = []
result = {'status': 'failed', 'mode': sys.flags.optimize, 'records': records,
          'scope': 'Two exact production entrypoint refusals and seven exact AST finally-body cases. Mocked snapshot effects only in finally cases. No complete admitted campaign, candidate or Lean execution.'}
try:
    for name, diagnostic in [('absent-freeze', 'FROZEN.json'),
                             ('unadopted-freeze', 'mean judge is not an adopted pre-candidate freeze')]:
        require(now() < DEADLINE, 'deadline before entrypoint')
        case = output / name
        case.mkdir()
        (case / 'campaign.py').write_bytes(source)
        (case / 'runtime.py').write_bytes(runtime)
        if name == 'unadopted-freeze':
            (case / 'FROZEN.json').write_bytes(canonical({'schema': 'pid-rs/prefix-mgw-mean-proof-judge-freeze-v1', 'status': 'proposed', 'candidate_exists': False}))
            (case / 'CAMPAIGN.json').write_bytes(canonical({}))
        argv = [sys.executable] + (['-O'] if sys.flags.optimize else []) + ['-I', '-S', '-B', str(case / 'campaign.py'), 'development', '--candidate-sha256', '0' * 64]
        registered = {'utc': now().isoformat(), 'argv': argv, 'cwd': str(case), 'source_sha256': digest(source)}
        (case / 'REGISTERED.json').write_bytes(canonical(registered))
        proc = subprocess.run(argv, cwd=case, capture_output=True, timeout=min(10, (DEADLINE - now()).total_seconds()))
        (case / 'stdout.log').write_bytes(proc.stdout)
        (case / 'stderr.log').write_bytes(proc.stderr)
        command = {**registered, 'returncode': proc.returncode, 'stdout_sha256': digest(proc.stdout), 'stderr_sha256': digest(proc.stderr), 'completed_utc': now().isoformat()}
        (case / 'command.json').write_bytes(canonical(command))
        require(proc.returncode != 0 and diagnostic.encode() in proc.stderr, 'wrong entrypoint refusal: ' + name)
        require(not (case / 'ATTEMPT_LEDGER.json').exists() and not (case / 'attempts').exists(), 'early refusal registered an attempt')
        records.append({'name': name, 'status': 'expected_refusal', 'returncode': proc.returncode, 'diagnostic': diagnostic})

    module = ast.parse(source)
    main = next(n for n in module.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
    final = next(n.finalbody for n in main.body if isinstance(n, ast.Try) and n.finalbody)
    code = compile(ast.fix_missing_locations(ast.Module(body=final, type_ignores=[])), 'production-campaign-finally-body', 'exec', optimize=sys.flags.optimize)
    (output / 'finally.ast.txt').write_text(ast.dump(ast.Module(body=final, type_ignores=[]), include_attributes=False))
    for name in ['positive', 'stop-during-save', 'expiry-during-save', 'drift-during-save', 'save-error', 'artifact-symlink', 'already-failed']:
        require(now() < DEADLINE, 'deadline before finally control')
        case = output / name
        case.mkdir()
        trial = {'status': 'failed' if name == 'already-failed' else 'fresh_semantic_kernel_pass'}
        fake_start = now()
        clock = [fake_start]
        trial_deadline = fake_start + dt.timedelta(seconds=1)
        class Snapshot:
            drift = False
            def manifest(self):
                return {'synthetic': 'no production input proof'}
            def save(self, where):
                (where / 'preserved.bin').write_bytes(b'preserved evidence')
                if name == 'stop-during-save':
                    (case / 'STOP_RECORD.json').write_bytes(b'{}')
                elif name == 'expiry-during-save':
                    clock[0] = trial_deadline
                elif name == 'drift-during-save':
                    self.drift = True
                elif name == 'save-error':
                    raise OSError('causal preservation error')
                elif name == 'artifact-symlink':
                    (where / 'bad-link').symlink_to('preserved.bin')
            def verify(self):
                require(not self.drift, 'causal input drift')
        scope = {'runner': None, 'snapshot': Snapshot(), 'result': trial, 'output': case,
                 'stat': stat, 'LANE': case, 'utc': lambda: clock[0], 'deadline': trial_deadline,
                 'j': types.SimpleNamespace(require=require, digest=digest, canonical=canonical)}
        stream = io.StringIO()
        with contextlib.redirect_stdout(stream):
            exec(code, scope)
        (case / 'stdout.log').write_text(stream.getvalue())
        terminal = json.loads((case / 'RESULT.json').read_bytes())
        expected = 'fresh_semantic_kernel_pass' if name == 'positive' else 'failed'
        require(terminal['status'] == expected, 'incorrect finally disposition: ' + name)
        field = {'stop-during-save': 'final_custody_failure', 'expiry-during-save': 'final_custody_failure', 'drift-during-save': 'final_custody_failure', 'save-error': 'preservation_failure', 'artifact-symlink': 'artifact_failure'}.get(name)
        if field:
            require(field in terminal, 'missing causal error: ' + name)
        records.append({'name': name, 'status': 'passed', 'terminal_status': terminal['status'], 'causal_field': field})
    require(now() < DEADLINE, 'deadline after controls')
    result['status'] = 'passed'
except BaseException as error:
    result['failure'] = repr(error)
finally:
    result['completed_utc'] = now().isoformat()
    result['artifacts'] = {}
    for path in sorted(output.rglob('*')):
        if path.is_symlink():
            continue  # The deliberate symlink is recorded by its causal failure, never followed.
        if path.is_file():
            raw = path.read_bytes()
            result['artifacts'][str(path.relative_to(output))] = {'sha256': digest(raw), 'bytes': len(raw)}
    if now() >= DEADLINE:
        result.update(status='failed', final_deadline_failure=True)
    (output / 'RESULT.json').write_bytes(canonical(result))
    print(json.dumps({'status': result['status'], 'cases': len(records), 'failure': result.get('failure')}))
raise SystemExit(0 if result['status'] == 'passed' else 1)
