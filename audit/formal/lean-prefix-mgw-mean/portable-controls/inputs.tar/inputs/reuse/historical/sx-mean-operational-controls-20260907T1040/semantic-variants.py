"""Three valid synthetic wrong-target/roster controls; no terminal theorem proofs."""
from __future__ import annotations
import ast, datetime, fcntl, hashlib, json, os
from pathlib import Path
import sys
from types import ModuleType
P=Path(__file__).resolve().parent

def main():
    if not(sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode and sys.flags.optimize==0):raise RuntimeError('registered normal mode only')
    frozen=(P/'SEMANTIC_VARIANT_FREEZE.json').read_bytes();freeze=json.loads(frozen);buffers={}
    for name,sha in freeze['files'].items():
        raw=(P/name).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=sha:raise RuntimeError('variant input drift '+name)
        buffers[name]=raw
    j=ModuleType('variant_runtime');j.__file__=str(P/'runtime.py');exec(compile(buffers['runtime.py'],j.__file__,'exec',dont_inherit=True),j.__dict__)
    lock=(P/'MINI_EXECUTION.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    reg=j.strict_json(buffers['REGISTRATION.json']);deadline=datetime.datetime.fromisoformat(reg['deadline_utc'])
    output=P/'semantic-variants-0';output.mkdir(exist_ok=False);snapshot=j.Snapshot();records=[];result={'status':'failed','scope':'Three synthetic final-type/environment controls only. Normal mode; no terminal law proof or full candidate replay.'};runner=None
    try:
        for name,raw in buffers.items():j.require(snapshot.read(P/name)==raw,'variant executed source changed')
        baseout=P/'mini-output-0-1';old=j.strict_json(buffers['mini-output-0-1/RESULT.json'])
        j.require(old['status']=='operational_miniature_pass','positive miniature absent')
        observed=j.strict_json(snapshot.read(P.parent/'sx-prefix-mgw-mean-type-preparation-20260906/runs/full-normal-01/environment.json'))
        for n,h in observed['tools'].items():j.require(j.digest(snapshot.read(Path(n)))==h,'tool changed')
        lean=next(n for n in observed['tools'] if n.endswith('/bin/lean'))
        env={'PATH':str(Path(lean).parent)+':/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8'}
        runner=j.Runner(output,env,preparation=False)
        execute_node=next(n for n in ast.walk(ast.parse(buffers['mini-driver.py'])) if isinstance(n,ast.FunctionDef) and n.name=='execute')
        exec_env={'snapshot':snapshot,'j':j,'LANE':P,'deadline':deadline,'datetime':datetime,'ledger_path':P/'EXECUTION_LEDGER.jsonl','registration':reg,'output':output,'sys':sys,'freeze_raw':frozen,'json':json,'os':os,'runner':runner}
        exec(compile(ast.fix_missing_locations(ast.Module(body=[execute_node],type_ignores=[])),'frozen-mini-child-route','exec'),exec_env)
        source_original=(baseout/'src/PidPrefixMgwMean/Candidate.lean').read_text()
        standard='∀ (A : Type u) (B : Type v) (C : Type w), A → B → C → (3 : Nat) = 3'
        variants=[('implicit-receiver','∀ (A : Type u) (B : Type v) (C : Type w), A → B → C → ∀ {_h : True}, (3 : Nat) = 3','  intro _ _ _ _ _ _ _\n  rfl\n','type mismatch'),('specialized-universe',standard.replace('Type u','Type'),'  intro _ _ _ _ _ _\n  rfl\n','type mismatch'),('extra-public-export',None,None,'PREFIX_MGW_MEAN_JUDGE_EXPORT_ROSTER')]
        for label,target,proof,diagnostic in variants:
            d=output/label;d.mkdir();src=d/'src';build=d/'build';src.mkdir();build.mkdir()
            for q in sorted((baseout/'src').rglob('*.lean')):
                rel=q.relative_to(baseout/'src');raw=snapshot.read(q);key='src/'+rel.as_posix()
                j.require(j.digest(raw)==old['artifacts'][key]['sha256'],'positive source drift')
                if rel.as_posix()=='PidPrefixMgwMean/Candidate.lean':
                    text=raw.decode()
                    if target is None:text=text.replace('end PidPrefixMgwMeanCandidate','theorem accidental_extra_export : True := by trivial\nend PidPrefixMgwMeanCandidate')
                    else:
                        start=text.index('private theorem proof_2');end=text.index('theorem word_coefficient_join_power',start)
                        text=text[:start]+'private theorem proof_2 : '+target+' := by\n'+proof+text[end:]
                        text=text.replace('theorem prefix_expectations_to_mgw_mean : '+standard,'theorem prefix_expectations_to_mgw_mean : '+target)
                    raw=text.encode()
                dest=src/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);snapshot.read(dest)
            for q in sorted((baseout/'build').rglob('*.olean')):
                rel=q.relative_to(baseout/'build')
                if rel.as_posix() in ('PidPrefixMgwMean/Candidate.olean','PidPrefixMgwMean/SemanticJudge.olean','MeanReporterMiniRoot.olean'):continue
                raw=snapshot.read(q);j.require(j.digest(raw)==old['artifacts']['build/'+rel.as_posix()]['sha256'],'positive object drift')
                dest=build/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);snapshot.read(dest)
            runner.environment['LEAN_PATH']=str(build)+os.pathsep+os.pathsep.join(observed['lean_search_path'].split(os.pathsep)[1:]);runner.environment['LEAN_SRC_PATH']=str(src);exec_env['src']=src
            def compile_one(module):
                dest=build/(module+'.olean');dest.parent.mkdir(parents=True,exist_ok=True)
                value=exec_env['execute'](label+'-'+module.replace('/','-'),[lean,'-t','0','-M','4096','-o',str(dest),str(src/(module+'.lean'))],module.endswith('SemanticJudge'))
                snapshot.read(dest);return value
            compile_one('PidPrefixMgwMean/Candidate');before=len(runner.commands)
            try:compile_one('PidPrefixMgwMean/SemanticJudge')
            except j.JudgeError:
                if len(runner.commands)==before:raise
                c=runner.commands[-1];log=output/(str(len(runner.commands)-1).zfill(2)+'-'+c['label'])/'stdout.log';text=log.read_text()
                j.require(c['failure'] is None and c['returncode']!=0 and diagnostic.lower() in text.lower(),'semantic variant failed for unrelated cause')
                records.append({'variant':label,'status':'expected_semantic_rejection','diagnostic':diagnostic,'source_sha256':j.digest((src/'PidPrefixMgwMean/Candidate.lean').read_bytes()),'stdout_sha256':j.digest(log.read_bytes())})
            else:raise j.JudgeError('incorrect variant admitted')
        snapshot.verify();j.require(not(P/'STOP_RECORD.json').exists(),'stage stopped');j.require(datetime.datetime.now(datetime.timezone.utc)<deadline,'deadline before closure');result['status']='passed'
    except BaseException as error:result['failure']=str(error)
    finally:
        result.update(records=records,commands=[] if runner is None else runner.commands,inputs=snapshot.manifest(),completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        try:snapshot.save(output)
        except BaseException as error:result.update(status='failed',preservation_failure=str(error))
        result['artifacts']={str(q.relative_to(output)):{'sha256':j.digest(q.read_bytes()),'bytes':len(q.read_bytes())} for q in sorted(output.rglob('*')) if q.is_file()}
        try:
            snapshot.verify();j.require(not(P/'STOP_RECORD.json').exists(),'stage stopped during final preservation');j.require(datetime.datetime.now(datetime.timezone.utc)<deadline,'deadline during final preservation')
        except BaseException as error:result.update(status='failed',final_custody_failure=str(error))
        result['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        (output/'RESULT.json').write_bytes(j.canonical(result));print(json.dumps({'status':result['status'],'controls':len(records),'failure':result.get('failure')}))
    return 0 if result['status']=='passed' else 1
if __name__=='__main__':raise SystemExit(main())
