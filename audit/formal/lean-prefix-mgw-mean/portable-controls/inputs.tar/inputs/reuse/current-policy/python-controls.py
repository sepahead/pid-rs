"""Retained-input production policy/parser and guard-fragment controls. No theorem proof credit."""
from __future__ import annotations
import ast, copy, datetime, fcntl, hashlib, json, os
from pathlib import Path
import sys
from types import ModuleType, SimpleNamespace

LANE=Path(__file__).resolve().parent
ROOT=LANE.parent.parent

def main():
    if not (sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode and sys.flags.optimize in (0,1)):
        raise RuntimeError('requires isolated Python -I -S -B, optionally -O')
    freeze_raw=(LANE/'PYTHON_CONTROL_FREEZE.json').read_bytes();freeze=json.loads(freeze_raw)
    modules={};buffers={}
    for name,expected in freeze['files'].items():
        raw=(LANE/name).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=expected:raise RuntimeError('input drift: '+name)
        buffers[name]=raw
        if name in ('runtime.py','policy.py','prefix-policy.py','mgw-policy.py','campaign.py'):
            mod=ModuleType('terminal_control_'+name.replace('-','_').replace('.','_'));mod.__file__=str(LANE/name)
            exec(compile(raw,str(LANE/name),'exec',dont_inherit=True,optimize=sys.flags.optimize),mod.__dict__)
            modules[name]=mod
    j=modules['runtime.py'];policy=modules['policy.py'];prefix=modules['prefix-policy.py'];campaign=modules['campaign.py'];mgw=modules['mgw-policy.py']
    registration=j.strict_json((LANE/'REGISTRATION.json').read_bytes())
    deadline=datetime.datetime.fromisoformat(registration['deadline_utc'])
    j.require(datetime.datetime.now(datetime.timezone.utc)<deadline,'operational deadline exhausted')
    output=LANE/('python-controls-'+str(sys.flags.optimize));output.mkdir(exist_ok=False)
    snapshot=j.Snapshot();records=[];result={'status':'failed','mode':sys.flags.optimize,'scope':'Actual policy/parser and extracted production guard fragments, not a complete campaign replay; zero terminal theorem proofs.'}
    def control(label,raw,call,expected=None):
        j.require(datetime.datetime.now(datetime.timezone.utc)<deadline,'operational deadline exhausted')
        directory=output/(str(len(records)).zfill(3)+'-'+label);directory.mkdir()
        (directory/'INPUT.bin').write_bytes(raw)
        rec={'control':label,'input_sha256':j.digest(raw),'expected':expected,'status':'failed'}
        try:
            value=call()
            if expected is not None:raise RuntimeError('unexpected admission')
            rec.update(status='accepted-as-required',returned=repr(value))
        except BaseException as error:
            rec['observed_error']=str(error)
            if expected is not None and expected in str(error):rec['status']='refused-as-required'
            else:raise
        finally:
            (directory/'RESULT.json').write_bytes(j.canonical(rec));records.append(rec)
    try:
        snapshot.read(LANE/'PYTHON_CONTROL_FREEZE.json')
        for name,raw in buffers.items():j.require(snapshot.read(LANE/name)==raw,'executed input buffer drift')
        _,base=j.load_helpers(ROOT,snapshot)
        header='\n'.join('import '+n for n in policy.IMPORTS)+'\nset_option autoImplicit false\nset_option warningAsError true\nuniverse u v w\nnamespace PidPrefixMgwMeanCandidate\n'
        helpers=''.join('private theorem proof_'+str(i)+' : True := by trivial\n' for i in range(3))
        aliases=''.join('theorem '+n+' : True := @proof_'+str(i)+'\n' for i,n in enumerate(policy.THEOREMS))
        source=header+helpers+aliases+'end PidPrefixMgwMeanCandidate\n'
        def grammar(label,text,expected=None,final=False):
            raw=text.encode();control('source-'+label,raw,lambda:policy.candidate_policy(raw,base,output/'synthetic-grammar.lean',final_control=final),expected)
        grammar('complete',source);grammar('comments','/- synthetic only -/\n'+source)
        for label,text,error in [
            ('missing-import',source.replace('import PidPrefixProbability.Candidate\n',''),'import roster'),
            ('extra-import','import Mathlib\n'+source,'import roster'),
            ('reordered-imports',source.replace('\n'.join('import '+n for n in policy.IMPORTS),'\n'.join('import '+n for n in reversed(policy.IMPORTS))),'import roster'),
            ('namespace',source.replace('namespace PidPrefixMgwMeanCandidate','namespace Other'),'namespace differs'),
            ('ending',source.replace('end PidPrefixMgwMeanCandidate','end Other'),'closing differs'),
            ('options',source.replace('warningAsError true','warningAsError false'),'strict options'),
            ('universes',source.replace('universe u v w','universe u'),'universes differ'),
            ('missing-export',source.replace('theorem word_coefficient_join_power : True := @proof_0\n',''),'source roster'),
            ('extra-export',source.replace('end PidPrefixMgwMeanCandidate','theorem extra : True := @proof_0\nend PidPrefixMgwMeanCandidate'),'source roster'),
            ('public-lemma',source.replace('theorem word_coefficient_join_power','lemma word_coefficient_join_power'),'not a theorem'),
            ('nonalias',source.replace(':= @proof_0',':= by trivial'),'direct private proof alias'),
            ('nonprivate-alias',source.replace(':= @proof_0',':= True.intro'),'direct private proof alias'),
            ('helper-after-public',source.replace('end PidPrefixMgwMeanCandidate','private theorem late : True := by trivial\nend PidPrefixMgwMeanCandidate'),'private helper must precede'),
        ]:grammar(label,text,error)
        for token in ('sorry','axiom','native_decide','run_cmd','unsafe','attribute','instance','#check','def','class'):
            grammar('forbidden-'+token.replace('#',''),source.replace('by trivial','by '+token,1),'prohibited code')
        mutant=source.replace('theorem prefix_expectations_to_mgw_mean : True := @proof_2','theorem prefix_expectations_to_mgw_mean : True := by trivial')
        grammar('trusted-final',mutant,None,True);grammar('same-final-normal',mutant,'direct private proof alias')
        grammar('trusted-first-not-relaxed',mutant.replace(':= @proof_0',':= by trivial'),'direct private proof alias',True)
        grammar('trusted-final-not-arbitrary',mutant.replace('prefix_expectations_to_mgw_mean : True','prefix_expectations_to_mgw_mean : False'),'exact trusted replacement',True)
        shapes=[{'theorem':'PidPrefixMgwMeanCandidate.'+n,'raw_target':'PidPrefixMgwMeanRawTargets.'+n,'alias_target':'PidPrefixMgwMeanAliasTargets.'+n,'universes':['u','v','w'],'full_elaborated_type':'Synthetic schema only; not theorem evidence','axioms':[],'status':'accepted'} for n in policy.THEOREMS]
        def encode(values,prefix_text='PREFIX_MGW_MEAN_JUDGE_RESULT '):return ('\n'.join(prefix_text+json.dumps(x,sort_keys=True) for x in values)+'\n').encode()
        def parse(label,raw,expected=None,which=policy):control('parser-'+label,raw,lambda:which.semantic_records(raw,j.strict_json),expected)
        parse('complete',encode(shapes));parse('missing',encode(shapes[:-1]),'record count');parse('extra',encode(shapes+[shapes[0]]),'record count')
        parse('reordered',encode(list(reversed(shapes))),'identity differs');parse('duplicate',encode([shapes[0]]*3),'identity differs');parse('prefix',encode(shapes,'OTHER '),'record prefix')
        mutations=[('theorem','Other.theorem','identity differs'),('raw_target','Other.raw','identity differs'),('alias_target','Other.alias','identity differs'),('status',True,'identity differs'),('universes',[],'universes differ'),('universes',['u','u','w'],'universes differ'),('universes',['u',False,'w'],'universes differ'),('axioms',['sorryAx'],'axiom policy'),('axioms',['propext','Classical.choice'],'axiom policy'),('axioms',['propext','propext'],'axiom policy'),('axioms',[False],'axiom policy'),('full_elaborated_type',' ','type is absent')]
        for i in range(3):
            for k,(field,value,error) in enumerate(mutations):
                vals=copy.deepcopy(shapes);vals[i][field]=value;parse(str(i)+'-'+str(k),encode(vals),error)
        vals=copy.deepcopy(shapes);vals[0]['extra']=0;parse('extra-field',encode(vals),'fields differ')
        vals=copy.deepcopy(shapes);del vals[0]['status'];parse('missing-field',encode(vals),'fields differ')
        parse('duplicate-json-key',encode(shapes).replace(b'"status": "accepted"',b'"status": "accepted", "status": "accepted"',1),'duplicate JSON key')
        parse('nonfinite-json',encode(shapes).replace(b'"status": "accepted"',b'"status": NaN',1),'nonfinite JSON')
        oldraw=buffers['accepted-prefix-stdout.log'];parse('actual-prior-six',oldraw,None,prefix)
        parse('six-cannot-be-three',oldraw,'record count');parse('three-cannot-be-six',encode(shapes),'record count',prefix)
        oldmgw=buffers['accepted-mgw-stdout.log'];parse('actual-prior-eleven',oldmgw,None,mgw)
        parse('eleven-cannot-be-three',oldmgw,'record count');parse('three-cannot-be-eleven',encode(shapes),'record count',mgw)
        parse('six-cannot-be-eleven',oldraw,'record count',mgw);parse('eleven-cannot-be-six',oldmgw,'record count',prefix)
        grammar('missing-mgw-import',source.replace('import PidMgwBridge.Candidate\n',''),'import roster')
        # Compile exact acceptance-bearing expressions from the frozen production source.
        tree=ast.parse(buffers['campaign.py']);main_node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
        calls=[n for n in ast.walk(main_node) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='j' and n.func.attr=='require' and len(n.args)>1 and isinstance(n.args[1],ast.Constant)]
        guards={str(n.args[1].value):n.args[0] for n in calls}
        common=dict(campaign.__dict__);common.update(j=j)
        def guard(label,diagnostic,context,accepted):
            expression=guards[diagnostic];raw=ast.get_source_segment(buffers['campaign.py'].decode(),expression).encode()
            data=json.dumps({'production_expression':raw.decode(),'context':repr(context)},sort_keys=True).encode()
            def invoke():
                condition=eval(compile(ast.Expression(expression),'frozen-production-guard','eval'),dict(common,**context))
                j.require(condition,diagnostic)
            control('guard-'+label,data,invoke,None if accepted else diagnostic)
        for value,accepted in ((0,True),(False,False),(0.0,False),(1,False)):
            guard('control-zero-'+type(value).__name__+'-'+str(value),'wrapper controls lack completed adoption',{'controls':{'status':'adopted_completed_operational_controls','new_mean_theorems_proved':value}},accepted)
        for status,accepted in [('adopted_after_actual_controls_before_candidate',True),('proposal_only_not_adopted',False)]:
            guard('freeze-'+str(accepted),'mean judge is not an adopted pre-candidate freeze',{'freeze':{'schema':'pid-rs/prefix-mgw-mean-proof-judge-freeze-v1','status':status,'candidate_exists':False}},accepted)
        for val in (False,True):guard('required-pins-'+str(val),'required wrapper/source/adoption pins absent',{'freeze':{'wrapper_sha256':dict.fromkeys(campaign.REQUIRED_WRAPPER_FILES,'a') if val else {}}},val)
        # These guards have dynamic diagnostics; use their exact AST expressions separately.
        bound=next(n for n in ast.walk(main_node) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='require' and len(n.args)>1 and isinstance(n.args[1],ast.BinOp) and isinstance(n.args[1].left,ast.Constant) and n.args[1].left.value=='fixed future campaign bound differs: ')
        for field,expected in [('max_development_attempts',80),('max_full_attempts',8),('max_concurrent_wrappers',1)]:
            for value in (expected,False,float(expected),expected+1):
                ctx=dict(common,task={field:value},field=field,expected=expected)
                raw=json.dumps({'field':field,'value':value,'type':type(value).__name__}).encode()
                control('bound-'+field+'-'+type(value).__name__+'-'+str(value),raw,lambda ctx=ctx:j.require(eval(compile(ast.Expression(bound.args[0]),'production-bound','eval'),ctx),'bound differs'),None if type(value)is int and value==expected else 'bound differs')
        guard('scope-good','candidate write scope differs',{'task':{'candidate_write_scope':'candidate/Candidate.lean'}},True)
        guard('scope-bad','candidate write scope differs',{'task':{'candidate_write_scope':'anywhere'}},False)
        now=datetime.datetime.now(datetime.timezone.utc)
        for label,start,end,accepted in [('valid',now-datetime.timedelta(minutes=1),now+datetime.timedelta(minutes=119),True),('future',now+datetime.timedelta(minutes=1),now+datetime.timedelta(minutes=121),False),('short',now-datetime.timedelta(minutes=1),now+datetime.timedelta(minutes=118),False)]:
            guard('clock-'+label,'campaign clock is not the registered 120-minute interval',{'registered':start,'declared_deadline':end,'utc':lambda:now},accepted)
        guard('expired','campaign deadline exhausted',{'deadline':now-datetime.timedelta(seconds=1),'utc':lambda:now},False)
        for used,limit,accepted in [(0,8,True),(8,8,False)]:guard('slot-'+str(used),'attempt limit exhausted',{'used':used,'task':{'max_full_attempts':limit},'slot_kind':'full'},accepted)
        # Active guards are the exact module-loop prefix before the actual Runner call.
        module_loop=next(n for n in ast.walk(main_node) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='module' and isinstance(n.iter,ast.Name) and n.iter.id=='modules')
        prefix_body=module_loop.body[:next(i for i,n in enumerate(module_loop.body) if isinstance(n,ast.Try))]
        fragment=compile(ast.fix_missing_locations(ast.Module(body=prefix_body,type_ignores=[])),'production-launch-prefix','exec')
        for label,stop,exhaust,accepted in [('positive',False,False,True),('stop-between',True,False,False),('deadline-after-rehash',False,True,False)]:
            case=output/('launch-'+label);case.mkdir();clock=[now]
            def verify(case=case,stop=stop,exhaust=exhaust):
                if stop:(case/'STOP_RECORD.json').write_text('synthetic stop')
                if exhaust:clock[0]=now+datetime.timedelta(seconds=3)
            ctx=dict(common,LANE=case,snapshot=SimpleNamespace(verify=verify),build=case/'build',module='Synthetic',deadline=now+datetime.timedelta(seconds=1),utc=lambda:clock[0])
            control('launch-'+label,ast.unparse(ast.Module(body=prefix_body,type_ignores=[])).encode(),lambda ctx=ctx:exec(fragment,ctx),None if accepted else ('stopped' if stop else 'deadline exhausted'))
        final_try=next(n for n in ast.walk(main_node) if isinstance(n,ast.Try) and any(isinstance(x,ast.Expr) and isinstance(x.value,ast.Call) and len(x.value.args)>1 and isinstance(x.value.args[1],ast.Constant) and x.value.args[1].value=='campaign stopped during final evidence preservation' for x in n.body))
        final_code=compile(ast.fix_missing_locations(ast.Module(body=[final_try],type_ignores=[])),'production-final-custody','exec')
        for label,stop,expire,drift in [('positive',False,False,False),('stop-during-preservation',True,False,False),('expiry-during-preservation',False,True,False),('drift-during-preservation',False,False,True)]:
            case=output/('final-'+label);case.mkdir();clock=[now];actual={'status':'fresh_semantic_kernel_pass'}
            if stop:(case/'STOP_RECORD.json').write_text('synthetic STOP after evidence preservation')
            if expire:clock[0]=now+datetime.timedelta(seconds=2)
            def verify(drift=drift):
                if drift:raise RuntimeError('input changed after evidence preservation')
            ctx=dict(common,LANE=case,snapshot=SimpleNamespace(verify=verify),result=actual,deadline=now+datetime.timedelta(seconds=1),utc=lambda:clock[0])
            def run_final(ctx=ctx,actual=actual,expected=(not(stop or expire or drift))):
                exec(final_code,ctx)
                j.require((actual['status']=='fresh_semantic_kernel_pass') is expected,'final custody disposition differs')
                return actual
            control('final-'+label,ast.unparse(final_try).encode(),run_final)
        # Actual immutable-snapshot refusal, not a simulated source digest predicate.
        case=output/'snapshot-controls';case.mkdir();path=case/'input';path.write_bytes(b'initial');snap=j.Snapshot();snap.read(path);path.write_bytes(b'changed')
        control('snapshot-drift',b'initial -> changed',snap.verify,'input changed')
        link=case/'symlink';link.symlink_to(path)
        control('snapshot-symlink',b'symlink input',lambda:j.Snapshot().read(link),'noncanonical or symlink')
        control('candidate-hash',b'actual',lambda:j.check_candidate_hash(b'actual','0'*64),'digest mismatch')
        lockpath=case/'lock';f1=lockpath.open('a+');f2=lockpath.open('a+')
        fcntl.flock(f1,fcntl.LOCK_EX|fcntl.LOCK_NB)
        control('concurrent-lock',b'two independent opens of the same lock',lambda:fcntl.flock(f2,fcntl.LOCK_EX|fcntl.LOCK_NB),'Resource temporarily unavailable')
        f2.close();f1.close()
        snapshot.verify();j.require(datetime.datetime.now(datetime.timezone.utc)<deadline,'deadline before closure')
        result['status']='passed'
    except BaseException as error:result['failure']=str(error)
    finally:
        result['records']=records;result['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();result['inputs']=snapshot.manifest()
        try:snapshot.save(output)
        except BaseException as error:result.update(status='failed',preservation_failure=str(error))
        result['artifacts']={str(q.relative_to(output)):{'sha256':j.digest(q.read_bytes()),'bytes':len(q.read_bytes())} for q in sorted(output.rglob('*')) if q.is_file()}
        try:
            snapshot.verify()
            j.require(not (LANE/'STOP_RECORD.json').exists(),'stage stopped during final evidence preservation')
            j.require(datetime.datetime.now(datetime.timezone.utc)<deadline,'deadline during final evidence preservation')
        except BaseException as error:result.update(status='failed',final_custody_failure=str(error))
        result['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        (output/'RESULT.json').write_bytes(j.canonical(result));print(json.dumps({'status':result['status'],'controls':len(records),'output':str(output),'failure':result.get('failure')}))
    return 0 if result['status']=='passed' else 1
if __name__=='__main__':raise SystemExit(main())
