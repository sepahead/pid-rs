"""Exact source policy and selected production AST controls. No Lean or full entrypoint."""
import ast
import datetime as dt
import hashlib
import json
import pathlib
import sys
import types

LANE = pathlib.Path(__file__).resolve().parent
ROOT = LANE.parent.parent
def digest(raw):
    return hashlib.sha256(raw).hexdigest()
def require(value, message):
    if not value:
        raise RuntimeError(message)
def canonical(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()

require(sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode, 'isolated flags')
freeze_raw = (LANE / 'PYTHON_CONTROL_FREEZE.json').read_bytes()
freeze = json.loads(freeze_raw)
buffers = {}
for name, sha in freeze['files'].items():
    raw = (LANE / name).read_bytes()
    require(digest(raw) == sha, 'frozen input differs: ' + name)
    buffers[name] = raw
def module(name):
    m = types.ModuleType(name)
    m.__file__ = str(LANE / name)
    exec(compile(buffers[name], m.__file__, 'exec', optimize=sys.flags.optimize), m.__dict__)
    return m
j, policy, campaign = module('runtime.py'), module('policy.py'), module('campaign.py')
deadline = dt.datetime.fromisoformat(json.loads(buffers['REGISTRATION.json'])['deadline_utc'])
out = LANE / ('helper-controls-' + str(sys.flags.optimize))
out.mkdir()
snapshot = j.Snapshot()
records = []
result = {'status': 'failed', 'mode': sys.flags.optimize, 'records': records,
          'scope': 'Successor grammar and actual selected caller/adoption/status/prior-pass expressions. Synthetic grammar proofs are not compiled. No mean proof or full entrypoint.'}
try:
    snapshot.read(LANE / 'PYTHON_CONTROL_FREEZE.json')
    for name, raw in buffers.items():
        require(snapshot.read(LANE / name) == raw, 'executed input differs')
    _, base = j.load_helpers(ROOT, snapshot)
    header = '\n'.join('import ' + n for n in policy.IMPORTS) + '\nset_option autoImplicit false\nset_option warningAsError true\nuniverse u v w\nnamespace PidPrefixMgwMeanCandidate\n'
    helpers = ''.join('private theorem proof_' + str(i) + ' : True := by trivial\n' for i in range(3))
    exports = ['theorem ' + n + ' : True := @proof_' + str(i) + '\n' for i, n in enumerate(policy.THEOREMS)]
    ending = 'end PidPrefixMgwMeanCandidate\n'
    def case(name, payload, call, error=None):
        require(dt.datetime.now(dt.timezone.utc) < deadline, 'control deadline')
        d = out / (str(len(records)).zfill(3) + '-' + name)
        d.mkdir()
        (d / 'INPUT.bin').write_bytes(payload)
        rec = {'name': name, 'input_sha256': digest(payload), 'expected_error': error}
        try:
            value = call()
            require(error is None, 'unexpected admission')
            rec.update(status='accepted-as-required', value=repr(value))
        except BaseException as e:
            rec['observed_error'] = str(e)
            if error is None or error not in str(e):
                rec['status'] = 'failed'
                raise
            rec['status'] = 'refused-as-required'
        finally:
            (d / 'RESULT.json').write_bytes(canonical(rec))
            records.append(rec)
    def grammar(name, body, error=None, **kwargs):
        raw = body.encode()
        case(name, raw, lambda: policy.candidate_policy(raw, base, out / 'synthetic.lean', **kwargs), error)
    private = header + helpers + ending
    full = header + helpers + ''.join(exports) + ending
    grammar('private-development', private, development_helpers=True)
    grammar('private-full-refusal', private, 'public theorem source roster')
    grammar('private-wrong-refusal', private, 'public theorem source roster', final_control=True)
    grammar('empty-development', header + ending, 'no proof declarations', development_helpers=True)
    grammar('full-normal', full)
    grammar('full-development', full, development_helpers=True)
    for mask in range(1, 7):
        grammar('partial-' + str(mask), header + helpers + ''.join(e for i, e in enumerate(exports) if mask & (1 << i)) + ending, 'public theorem source roster', development_helpers=True)
    for value in (0, 1, None, 'true'):
        grammar('nonbool-' + str(value), private, 'mode must be Boolean', development_helpers=value)
    grammar('mixed-flags', private, 'modes conflict', development_helpers=True, final_control=True)
    for name, body, error in [
        ('missing-import', private.replace('import PidMgwBridge.Candidate\n', ''), 'import roster'),
        ('extra-import', 'import Mathlib\n' + private, 'import roster'),
        ('namespace', private.replace('namespace PidPrefixMgwMeanCandidate', 'namespace Other'), 'namespace differs'),
        ('option', private.replace('warningAsError true', 'warningAsError false'), 'strict options'),
        ('universe', private.replace('universe u v w', 'universe u v'), 'universes differ'),
        ('extra-public', private.replace(ending, 'theorem unrelated : True := @proof_0\n' + ending), 'public theorem source roster'),
    ]:
        grammar(name, body, error, development_helpers=True)
    for token in ('sorry', 'axiom', 'native_decide', 'run_cmd', 'unsafe', 'attribute', 'instance', '#check', 'def', 'section', 'variable'):
        grammar('forbidden-' + token.replace('#', ''), private.replace('by trivial', 'by ' + token, 1), 'prohibited code', development_helpers=True)

    tree = ast.parse(buffers['campaign.py'])
    main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
    calls = [n for n in ast.walk(main) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and isinstance(n.func.value, ast.Name) and n.func.value.id == 'policy' and n.func.attr == 'candidate_policy']
    require(len(calls) == 2, 'policy call roster differs')
    call = next(n for n in calls if any(k.arg == 'development_helpers' for k in n.keywords))
    final_call = next(n for n in calls if n is not call)
    require([(k.arg, ast.literal_eval(k.value)) for k in final_call.keywords] == [('final_control', True)], 'wrong control call changed')
    for kind in ('development', 'full', 'wrong-last-target'):
        received = []
        scope = dict(policy=types.SimpleNamespace(candidate_policy=lambda *a, **kw: received.append(kw)), source=b'', base=None, candidate=None, args=types.SimpleNamespace(kind=kind))
        code = compile(ast.Expression(call), 'actual-production-policy-call', 'eval')
        def invoke(scope=scope, received=received, kind=kind):
            eval(code, scope)
            require(received == [{'development_helpers': kind == 'development'}], 'caller mode differs')
            return received
        case('caller-' + kind, ast.dump(call).encode(), invoke)
    guard = next(n.args[0] for n in ast.walk(main) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'require' and len(n.args) > 1 and isinstance(n.args[1], ast.Constant) and n.args[1].value == 'completed preparation lacks exact root adoption')
    adoption_raw = buffers['PREPARATION_ADOPTION.json']
    adoption = json.loads(adoption_raw)
    for name, data, changed_pin, accepted in [('actual', adoption, False, True), ('pending-pin', adoption, True, False), ('boolean-count', dict(adoption, new_mean_theorems=False), False, False), ('proof-upgrade', dict(adoption, new_mean_theorems=1), False, False)]:
        scope = dict(campaign.__dict__, j=j, adoption_raw=adoption_raw, adoption=data)
        if changed_pin:
            scope['PREPARATION_ADOPTION_SHA'] = None
        expression = compile(ast.Expression(guard), 'actual-adoption-guard', 'eval')
        case('adoption-' + name, canonical(data), lambda scope=scope: require(eval(expression, scope), 'adoption rejected'), None if accepted else 'adoption rejected')
    status_expr = next(n.value for n in ast.walk(main) if isinstance(n, ast.Assign) and isinstance(n.value, ast.IfExp) and isinstance(n.value.body, ast.Constant) and n.value.body.value == 'fresh_semantic_kernel_pass')
    for kind, expected in [('development', 'development_compile_pass'), ('full', 'fresh_semantic_kernel_pass')]:
        case('status-' + kind, ast.dump(status_expr).encode(), lambda kind=kind, expected=expected: require(eval(compile(ast.Expression(status_expr), 'actual-status-expression', 'eval'), {'args': types.SimpleNamespace(kind=kind)}) == expected, 'status differs'))
    prior = next(n.test for n in ast.walk(main) if isinstance(n, ast.If) and 'fresh_semantic_kernel_pass' in ast.dump(n.test) and 'original' in ast.dump(n.test))
    for status, accepted in [('fresh_semantic_kernel_pass', True), ('development_compile_pass', False), ('failed', False)]:
        ctx = {'body': {'status': status, 'registered': {'kind': 'full'}}, 'attempt': {'kind': 'full'}, 'original': b'original', 'source': b'original'}
        case('prior-' + status, canonical({'status': status}), lambda ctx=ctx, accepted=accepted: require(bool(eval(compile(ast.Expression(prior), 'actual-prior-condition', 'eval'), ctx)) is accepted, 'prior qualification differs'))
    snapshot.verify()
    result['status'] = 'passed'
except BaseException as error:
    result['failure'] = repr(error)
finally:
    result['inputs'] = snapshot.manifest()
    snapshot.save(out)
    result['artifacts'] = {}
    for p in sorted(out.rglob('*')):
        if p.is_file():
            b = p.read_bytes()
            result['artifacts'][str(p.relative_to(out))] = {'bytes': len(b), 'sha256': digest(b)}
    try:
        snapshot.verify()
        require(dt.datetime.now(dt.timezone.utc) < deadline, 'deadline after preservation')
    except BaseException as error:
        result.update(status='failed', final_custody_failure=repr(error))
    result['completed_utc'] = dt.datetime.now(dt.timezone.utc).isoformat()
    (out / 'RESULT.json').write_bytes(canonical(result))
    print(json.dumps({'status': result['status'], 'cases': len(records), 'failure': result.get('failure')}))
raise SystemExit(0 if result['status'] == 'passed' else 1)
