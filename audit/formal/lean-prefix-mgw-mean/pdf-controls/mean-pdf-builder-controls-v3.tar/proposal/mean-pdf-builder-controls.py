#!/usr/bin/env python3
"""Full-entrypoint controls with inert executable tools; zero PDF production credit.

The three real-profile positives use exact current builder/profile bytes.
Toy negatives rebase only exact profile literals in private source copies.
One timeout case uses two seconds only for the Pandoc producer, with a four-second inert delay.
No candidate module is imported, and no real Pandoc, TeX or log checker runs.
"""
from __future__ import annotations
import argparse
import ast
import base64
from dataclasses import dataclass
import datetime as dt
import difflib
import hashlib
import json
import os
from pathlib import Path
import shlex
import signal
import stat
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
LANE = HERE.parent
EXPECTED_BUILDER = 'f21f065eee8fd4a77c373445d858430fc4fd968f2c2b63d983c948d8a1e6fac0'
NORMALIZED_BUILDER = 'ad7cd42e2ee34d373cde01663cb8ab4e2eb2730f6933fbd562b2811790971edb'
REAL_MANIFEST = '6f181dcb87d6398075a568ce0156df17081ea14fe68305f7b267f819c2a59ffa'
REAL_PDF = '93ff18e21f56e4770b12b7405d57b003bf7839cef5c4207ed98a56cd6f96f58f'
MANIFEST_PATH = 'audit/formal/latex/prefix-mgw-mean/publication-inputs-v1.json'
UNIT = 'audit/formal/lean-prefix-mgw-mean/'
ASSETS = 'audit/formal/latex/prefix-mgw-mean/'
STREAM_CAP = 1024 * 1024


@dataclass(frozen=True)
class Case:
    name: str
    mutation: str = ''
    fault: str = ''
    diagnostic: str = ''
    calls: int = 0
    expected_rc: int = 1
    check: bool = False
    real: bool = False
    before_work: bool = False
    output: str = ''


CASES = (
    Case('real-profile-exact', calls=6, expected_rc=0, real=True),
    Case('real-profile-check', calls=10, expected_rc=0, real=True, check=True),
    Case('real-profile-new-output', calls=6, expected_rc=0, real=True, output='new'),
    Case('selected-lualatex-name', calls=6, expected_rc=0, mutation='selector-link'),
    Case('cross-refusal', mutation='cross', diagnostic='status 2 refusal.', expected_rc=2, before_work=True, real=True),
    Case('unresolved-profile', mutation='unresolved', diagnostic='profile is unresolved', before_work=True),
    Case('unresolved-PDF-pin-only', mutation='unresolved-pdf', diagnostic='profile is unresolved', before_work=True),
    Case('unresolved-manifest-pin-only', mutation='unresolved-manifest', diagnostic='profile is unresolved', before_work=True),
    Case('manifest-byte-drift', mutation='manifest-bytes', diagnostic='publication manifest changed'),
    Case('duplicate-profile-key', mutation='duplicate-key', diagnostic='duplicate JSON key'),
    Case('nonfinite-profile-number', mutation='nonfinite', diagnostic='nonfinite JSON number'),
    Case('nonobject-profile', mutation='profile-list', diagnostic='manifest is not an object'),
    Case('wrong-profile-schema', mutation='schema', diagnostic='publication profile changed'),
    Case('boolean-page-count', mutation='bool-pages', diagnostic='publication profile changed'),
    Case('floating-page-count', mutation='float-pages', diagnostic='publication profile changed'),
    Case('wrong-profile-PDF-digest', mutation='profile-pdf', diagnostic='publication profile changed'),
    Case('unsafe-profile-source-path', mutation='unsafe-path', diagnostic='unsafe source path'),
    Case('missing-input', mutation='missing-input', diagnostic='EXPOSITION.current.md'),
    Case('changed-Markdown-input', mutation='changed-md', diagnostic='publication source changed: ' + UNIT + 'EXPOSITION.current.md'),
    Case('changed-figure-input', mutation='changed-figure', diagnostic='publication source changed: ' + ASSETS + 'retained-rank.pdf'),
    Case('symbolic-input', mutation='symbolic-input', diagnostic='source must be a direct single-link regular file'),
    Case('hardlinked-input', mutation='hardlink-input', diagnostic='source must be a direct single-link regular file'),
    Case('boolean-input-size', mutation='bool-bytes', diagnostic='publication source changed'),
    Case('floating-input-size', mutation='float-bytes', diagnostic='publication source changed'),
    Case('Markdown-title', mutation='md-title', diagnostic='title boundary changed', calls=2),
    Case('Markdown-verification-link', mutation='md-link', diagnostic='verification-link boundary changed', calls=2),
    Case('Markdown-figure-link', mutation='md-figure', diagnostic='figure-link boundary changed', calls=2),
    Case('Markdown-bias-companion-missing', mutation='md-companion-missing', diagnostic='bias-companion-link boundary changed', calls=2),
    Case('Markdown-bias-companion-duplicate', mutation='md-companion-duplicate', diagnostic='bias-companion-link boundary changed', calls=2),
    Case('Markdown-derived-body', mutation='md-body', diagnostic='derived Markdown differs', calls=2),
    Case('TeX-section-inventory', fault='tex-sections', diagnostic='section inventory changed', calls=3),
    Case('TeX-pagebreak-anchor', fault='tex-heading', diagnostic='page-flow boundary changed', calls=3),
    Case('TeX-derived-body', fault='tex-body', diagnostic='derived TeX differs', calls=3),
    Case('Pandoc-version', fault='pandoc-version', diagnostic='Pandoc version differs', calls=1),
    Case('LuaLaTeX-version', fault='lualatex-version', diagnostic='LuaLaTeX version differs', calls=2),
    Case('missing-selected-tool', mutation='missing-tool', diagnostic='missing command: bash'),
    Case('relative-tool-selector', mutation='relative-selector', diagnostic='tool selector must be absolute'),
    Case('selector-drift-before-launch', fault='selector-before', diagnostic='tool selector changed before launch', calls=1),
    Case('selector-drift-after-launch', fault='selector-after', diagnostic='tool selector changed during build', calls=6),
    Case('Pandoc-actual-nonzero', fault='pandoc-nonzero', diagnostic='pandoc failed', calls=3),
    Case('LuaLaTeX-actual-nonzero', fault='lualatex-nonzero', diagnostic='latex-1 failed', calls=4),
    Case('log-command-actual-nonzero', fault='log-nonzero', diagnostic='log-check failed', calls=6),
    Case('producer-zero-with-stderr', fault='producer-stderr', diagnostic='latex-1 emitted stderr', calls=4),
    Case('actual-subprocess-timeout', fault='timeout', diagnostic='timed out after', calls=3),
    Case('wrong-PDF-bytes', fault='wrong-pdf', diagnostic='rebuilt PDF is not the exact reviewed prototype', calls=6),
    Case('second-build-PDF-mismatch', fault='repeat-pdf', diagnostic='rebuilt PDF is not the exact reviewed prototype', calls=10, check=True),
    Case('source-byte-drift', fault='source-bytes', diagnostic='source/tool changed during build', calls=6),
    Case('source-mode-drift', fault='source-mode', diagnostic='source/tool changed during build', calls=6),
    Case('tool-byte-drift', fault='tool-bytes', diagnostic='source/tool changed during build', calls=6),
    Case('existing-work-directory', mutation='work-existing', diagnostic='work directory already exists', before_work=True),
    Case('symbolic-work-directory', mutation='work-link', diagnostic='work directory already exists', before_work=True),
    Case('existing-output-file', diagnostic='File exists', calls=6, output='existing'),
    Case('canonical-input-output', diagnostic='canonical reviewed PDF is an input', calls=6, output='canonical'),
    Case('symbolic-output-file', diagnostic='File exists', calls=6, output='symlink'),
    Case('symbolic-output-parent', diagnostic='directory must be canonical', calls=6, output='parent-link'),
    Case('missing-isolation-flag', mutation='without-isolation', diagnostic='requires Python 3.11+', before_work=True),
    Case('missing-work-argument', mutation='without-work', diagnostic='explicit fresh --work-dir', before_work=True),
    Case('unknown-option', mutation='unknown-option', diagnostic='unrecognized arguments', expected_rc=2, before_work=True),
)


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()


def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, 'duplicate control JSON key')
            result[key] = value
        return result
    def nonfinite(value):
        raise ValueError('nonfinite control JSON ' + value)
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=nonfinite)


def keep(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(value if isinstance(value, bytes) else canonical(value))


def source(path):
    require(path.absolute() == path.resolve(strict=True) and not path.is_symlink(),
            'noncanonical source: ' + str(path))
    metadata = path.stat()
    require(stat.S_ISREG(metadata.st_mode) and metadata.st_nlink == 1, 'nonregular control source')
    raw = path.read_bytes()
    identity = lambda value: (value.st_dev, value.st_ino, value.st_mode, value.st_nlink,
                              value.st_size, value.st_mtime_ns, value.st_ctime_ns)
    require(identity(path.stat()) == identity(metadata), 'control source changed while reading')
    return raw


def pin_values(raw, replacements):
    """Change only the two top-level data literals, never execute a candidate AST."""
    tree = ast.parse(raw.decode())
    lines = raw.splitlines(keepends=True)
    edits = []
    found = set()
    for node in tree.body:
        if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            name = node.target.id
        elif isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            name = node.targets[0].id
        else:
            continue
        if name not in replacements:
            continue
        require(name not in found and isinstance(node.value, ast.Constant), 'profile literal shape changed')
        value = node.value.value
        require(value is None or (type(value) is str and len(value) == 64
                and all(c in '0123456789abcdef' for c in value)), 'profile is not an exact digest literal')
        start = sum(map(len, lines[:node.value.lineno - 1])) + node.value.col_offset
        end = sum(map(len, lines[:node.value.end_lineno - 1])) + node.value.end_col_offset
        edits.append((start, end, repr(replacements[name]).encode()))
        found.add(name)
    require(found == set(replacements), 'profile literal inventory changed')
    for start, end, replacement in sorted(edits, reverse=True):
        raw = raw[:start] + replacement + raw[end:]
    return raw


def fixture(directory, case, builder_raw, toy):
    root = directory / 'root'
    root.mkdir()
    real = LANE / 'inputs/real-profile'
    if case.real:
        manifest_raw = source(real / 'publication-inputs-v1.json')
        require(digest(manifest_raw) == REAL_MANIFEST, 'real profile changed')
        manifest = strict_json(manifest_raw)
        values = {relative: source(real / 'tree' / relative) for relative in manifest['files']}
        raw_pandoc = source(real / 'body.pandoc.raw.tex')
        pdf = values['output/pdf/prefix-mgw-mean.pdf']
        require(digest(pdf) == REAL_PDF, 'real PDF identity changed')
    else:
        values = {relative: text.encode() for relative, text in toy['files'].items()}
        raw_pandoc = toy['pandoc_raw'].encode()
        pdf = toy['pdf_bytes'].encode()
        manifest = {'schema': 'pid-rs/prefix-mgw-mean-publication-inputs-v1',
                    'scope': 'INERT private profile; no actual PDF or producer acceptance',
                    'expected_pages': 9, 'expected_pdf_sha256': digest(pdf),
                    'files': {relative: {'bytes': len(raw), 'sha256': digest(raw)}
                              for relative, raw in values.items()}}
        manifest_raw = canonical(manifest)
    original_values = dict(values)
    mutation = case.mutation
    if mutation in ('md-title', 'md-link', 'md-figure', 'md-companion-missing', 'md-companion-duplicate'):
        relative = UNIT + 'EXPOSITION.current.md'
        before, after = {
            'md-title': (b'# From categorical exclusion events to MGW atom expectations', b'# Changed control title'),
            'md-link': (b'../../evidence/', b'../wrong-evidence/'),
            'md-figure': (b'](retained-rank.svg)', b'](wrong-figure.svg)'),
            'md-companion-missing': (b'](../lean-prefix-mgw-bias/EXPOSITION.md)', b'](../lean-prefix-mgw-bias/WRONG.md)'),
            'md-companion-duplicate': (b'](../lean-prefix-mgw-bias/EXPOSITION.md)', b'](../lean-prefix-mgw-bias/EXPOSITION.md)\n[duplicate](../lean-prefix-mgw-bias/EXPOSITION.md)'),
        }[mutation]
        require(values[relative].count(before) == 1, 'Markdown mutation anchor changed')
        values[relative] = values[relative].replace(before, after)
    elif mutation == 'md-body':
        values[ASSETS + 'body.expected.md'] += b'DELIBERATE EXPECTATION ERROR\n'
    if values != original_values:
        manifest['files'] = {relative: {'bytes': len(raw), 'sha256': digest(raw)} for relative, raw in values.items()}
    if mutation == 'schema':
        manifest['schema'] = 'wrong-control-schema'
    elif mutation == 'bool-pages':
        manifest['expected_pages'] = True
    elif mutation == 'float-pages':
        manifest['expected_pages'] = 9.0
    elif mutation == 'profile-pdf':
        manifest['expected_pdf_sha256'] = '0' * 64
    elif mutation == 'unsafe-path':
        manifest['files']['../escape'] = {'bytes': 0, 'sha256': digest(b'')}
    elif mutation == 'bool-bytes':
        manifest['files'][UNIT + 'EXPOSITION.current.md']['bytes'] = True
    elif mutation == 'float-bytes':
        manifest['files'][UNIT + 'EXPOSITION.current.md']['bytes'] = float(len(values[UNIT + 'EXPOSITION.current.md']))
    if not case.real:
        manifest_raw = canonical(manifest)
    if mutation == 'duplicate-key':
        manifest_raw = b'{"schema":"one","schema":"two"}\n'
    elif mutation == 'nonfinite':
        manifest_raw = b'{"poison":NaN}\n'
    elif mutation == 'profile-list':
        manifest_raw = b'[]\n'
    for relative, raw in values.items():
        keep(root / relative, raw)
        (root / relative).chmod(0o644)
    keep(root / MANIFEST_PATH, manifest_raw)
    executed = builder_raw if case.real else pin_values(builder_raw, {
        'MANIFEST_SHA': digest(manifest_raw), 'PDF_SHA': digest(pdf)})
    if mutation == 'unresolved':
        executed = pin_values(builder_raw, {'MANIFEST_SHA': None, 'PDF_SHA': None})
    elif mutation == 'unresolved-pdf':
        executed = pin_values(executed, {'PDF_SHA': None})
    elif mutation == 'unresolved-manifest':
        executed = pin_values(executed, {'MANIFEST_SHA': None})
    if case.fault == 'timeout':
        require(executed.count(b'timeout=300, check=False') == 1, 'timeout literal anchor changed')
        executed = executed.replace(b'timeout=300, check=False', b'timeout=(2 if label == \"pandoc\" else 300), check=False')
    builder = root / 'scripts/build-prefix-mgw-mean-pdf.py'
    keep(builder, executed)
    keep(directory / 'BUILDER_COPY.diff', ''.join(difflib.unified_diff(
        builder_raw.decode().splitlines(True), executed.decode().splitlines(True),
        fromfile='reviewed-builder', tofile='private-control-copy')).encode())
    if mutation == 'manifest-bytes':
        (root / MANIFEST_PATH).write_bytes(manifest_raw + b' ')
    elif mutation == 'missing-input':
        (root / (UNIT + 'EXPOSITION.current.md')).unlink()
    elif mutation == 'changed-md':
        path = root / (UNIT + 'EXPOSITION.current.md'); path.write_bytes(path.read_bytes() + b'changed\n')
    elif mutation == 'changed-figure':
        path = root / (ASSETS + 'retained-rank.pdf'); path.write_bytes(path.read_bytes() + b'changed\n')
    elif mutation in ('symbolic-input', 'hardlink-input'):
        path = root / (UNIT + 'retained-rank.svg')
        target = directory / 'owned-input-target'; keep(target, path.read_bytes()); path.unlink()
        if mutation == 'symbolic-input':
            path.symlink_to(target)
        else:
            os.link(target, path)
    tools = directory / 'tools'
    binary = tools / 'bin'; actual = tools / 'actual'
    binary.mkdir(parents=True); actual.mkdir()
    tool_script = directory / 'inert-pdf-tool.py'
    keep(tool_script, source(HERE / 'inert-pdf-tool.py'))
    plan_path = directory / 'TOOL_PLAN.json'
    wrapper = ('#!/bin/sh\nexec ' + shlex.quote(sys.executable)
               + ' -I -S -B ' + shlex.quote(str(tool_script)) + ' "$0" '
               + shlex.quote(str(plan_path)) + ' "$@"\n').encode()
    symlink_selector = mutation == 'selector-link' or case.fault in ('selector-before', 'selector-after')
    for name in ('pandoc', 'lualatex', 'bash'):
        if mutation == 'missing-tool' and name == 'bash':
            continue
        path = actual / 'lualatex-driver' if name == 'lualatex' and symlink_selector else binary / name
        keep(path, wrapper); path.chmod(0o755)
        if name == 'lualatex' and symlink_selector:
            (binary / name).symlink_to(path)
    alternate = actual / 'alternate-lualatex-driver'
    keep(alternate, wrapper); alternate.chmod(0o755)
    plan = {'schema': 'pid-rs/mean-pdf-inert-tool-plan-v1', 'fault': case.fault,
            'lualatex_selector': str(binary / 'lualatex'), 'alternate_lualatex_target': str(alternate),
            'pandoc_selector': str(binary / 'pandoc'), 'markdown_source': str(root / (UNIT + 'EXPOSITION.current.md')),
            'body_markdown_b64': base64.b64encode(original_values[ASSETS + 'body.expected.md']).decode(),
            'body_latex_b64': base64.b64encode(original_values[ASSETS + 'body.expected.tex']).decode(),
            'pandoc_raw_b64': base64.b64encode(raw_pandoc).decode(), 'pdf_b64': base64.b64encode(pdf).decode(),
            'log_source_b64': base64.b64encode(original_values['scripts/check-formal-pdf-log.sh']).decode()}
    keep(plan_path, plan)
    work = directory / 'work'
    if mutation == 'work-existing':
        work.mkdir(); keep(work / 'OWNED_MARKER', b'preserve work marker\n')
    elif mutation == 'work-link':
        target = directory / 'owned-work-target'; target.mkdir(); work.symlink_to(target)
    output = None
    protected = {}
    if case.output:
        output = directory / 'requested-output.pdf'
        if case.output == 'existing':
            keep(output, b'preserve existing output\n'); protected[output] = output.read_bytes()
        elif case.output == 'canonical':
            output = root / 'output/pdf/prefix-mgw-mean.pdf'; protected[output] = output.read_bytes()
        elif case.output == 'symlink':
            target = directory / 'owned-output-target'; keep(target, b'preserve symlink target\n')
            output.symlink_to(target); protected[target] = target.read_bytes()
        elif case.output == 'parent-link':
            target = directory / 'owned-output-parent'; target.mkdir()
            link = directory / 'output-parent-link'; link.symlink_to(target, target_is_directory=True)
            output = link / 'requested.pdf'
    keep(directory / 'CASE_INPUTS.json', {
        'case': case.__dict__, 'original_builder_sha256': digest(builder_raw),
        'executed_builder_sha256': digest(executed), 'manifest_before_drift_sha256': digest(manifest_raw),
        'manifest_executed_sha256': digest((root / MANIFEST_PATH).read_bytes()),
        'fixture_relation': 'real reviewed profile with inert tools' if case.real else 'private inert profile rebase',
        'timeout_source_substitution': '300 -> (2 if label == pandoc else 300); version probes unchanged' if case.fault == 'timeout' else None,
        'inputs': {relative: {'bytes': len(raw), 'sha256': digest(raw)} for relative, raw in values.items()},
        'no_real_production_or_proof_credit': True})
    return root, builder, executed, binary, work, output, protected, pdf


def run_case(directory, case, mode, builder_raw, toy, deadline):
    born = dt.datetime.now(dt.timezone.utc)
    try:
        root, builder, executed, binary, work, output, protected, pdf = fixture(directory, case, builder_raw, toy)
    except BaseException as error:
        keep(directory / 'CASE_RESULT.json', {'status': 'fixture_setup_failed', 'name': case.name, 'mode': mode,
             'failure': repr(error), 'builder_launched': False,
             'completed_utc': dt.datetime.now(dt.timezone.utc).isoformat()})
        raise
    flags = ['-I', '-S', '-B']
    if mode:
        flags.append('-O')
    if case.mutation == 'without-isolation':
        flags.remove('-I')
    argv = [sys.executable, *flags, str(builder), '--root', str(root)]
    argv.append('--cross-toolchain' if case.mutation == 'cross' else '--exact')
    if case.mutation != 'without-work':
        argv += ['--work-dir', str(work)]
    if case.check:
        argv.append('--check')
    if output is not None:
        argv += ['--output', str(output)]
    if case.mutation == 'unknown-option':
        argv.append('--unknown-control-option')
    environment = {'PATH': os.path.relpath(binary, root) if case.mutation == 'relative-selector' else str(binary),
                   'LANG': 'C', 'LC_ALL': 'C', 'TZ': 'UTC'}
    keep(directory / 'COMMAND.json', {'argv': argv, 'cwd': str(root), 'environment': environment,
                                      'registered_utc': born.isoformat(), 'per_case_seconds': 12})
    seconds = (deadline - dt.datetime.now(dt.timezone.utc)).total_seconds()
    require(seconds > 20, 'insufficient stage time before control spawn')
    process = None
    execution = {'status': 'failed', 'outer_timeout': False}
    try:
        with (directory / 'stdout.log').open('xb') as stdout, (directory / 'stderr.log').open('xb') as stderr:
            process = subprocess.Popen(argv, cwd=root, env=environment, stdin=subprocess.DEVNULL,
                                       stdout=stdout, stderr=stderr, start_new_session=True)
            execution['owned_pid'] = process.pid
            try:
                code = process.wait(timeout=min(12, seconds - 10))
            except subprocess.TimeoutExpired:
                execution['outer_timeout'] = True
                # Direct child is unreaped after wait timeout; this group is owned.
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=2)
                raise RuntimeError('outer fixture timeout cannot count as candidate rejection')
        execution['returncode'] = code
        stdout = (directory / 'stdout.log').read_bytes()
        stderr = (directory / 'stderr.log').read_bytes()
        require(len(stdout) <= STREAM_CAP and len(stderr) <= STREAM_CAP, 'outer stream cap exceeded')
        require(type(code) is int and code == case.expected_rc, 'actual builder exit differs from intended status')
        trace_path = directory / 'tool-trace.jsonl'
        trace = [strict_json(line) for line in trace_path.read_bytes().splitlines()] if trace_path.exists() else []
        started = [row for row in trace if row['event'] == 'started']
        completed = [row for row in trace if row['event'] == 'completed']
        expected_roles = ['pandoc', 'lualatex', 'pandoc', 'lualatex', 'lualatex', 'bash']
        if case.check:
            expected_roles += ['pandoc', 'lualatex', 'lualatex', 'bash']
        require([row['role'] for row in started] == expected_roles[:case.calls], 'intended producer boundary was not reached')
        require(len(completed) == case.calls - (1 if case.fault == 'timeout' else 0), 'inert producer completion inventory differs')
        for row in completed:
            expected_code = 7 if case.fault.endswith('nonzero') and row is completed[-1] else 0
            require(type(row['returncode']) is int and row['returncode'] == expected_code, 'inert tool exit mismatch')
        receipt_path = work / 'RESULT.json'
        receipt = strict_json(receipt_path.read_bytes()) if receipt_path.is_file() else None
        if case.before_work:
            require(receipt is None and not trace, 'early refusal created a receipt or ran a producer')
        else:
            require(type(receipt) is dict, 'builder terminal receipt missing')
            require(type(receipt['commands']) is list and len(receipt['commands']) == case.calls,
                    'builder command receipt inventory differs')
        if case.expected_rc == 0:
            count = 2 if case.check else 1
            require(not stderr, 'positive builder emitted stderr')
            require(stdout == ('OK: mean exposition exact reviewed PDF reproduced; builds=' + str(count) + '\n').encode(),
                    'positive transport text differs')
            require(receipt['status'] == 'exact_reviewed_pdf_reproduced'
                    and type(receipt['build_count']) is int and receipt['build_count'] == count
                    and receipt['pdf_sha256'] == digest(pdf)
                    and type(receipt['bytes']) is int and receipt['bytes'] == len(pdf)
                    and receipt['source_and_tools_unchanged'] is True, 'positive result tuple differs')
            for index in range(1, count + 1):
                require((work / ('build-' + str(index)) / 'prefix-mgw-mean.pdf').read_bytes() == pdf,
                        'positive actual output bytes differ')
            if output is not None:
                require(output.read_bytes() == pdf, 'new output bytes differ')
        else:
            require(not stdout and case.diagnostic in stderr.decode(), 'failure did not reach its causal diagnostic')
            if receipt is not None:
                require(receipt['status'] == 'failed' and type(receipt.get('failure')) is str,
                        'rejection lacks an actual failed receipt')
            if case.fault == 'timeout':
                require(receipt['commands'][-1].get('timed_out') is True, 'no actual subprocess timeout receipt')
            if case.fault.endswith('nonzero'):
                last_code = receipt['commands'][-1].get('returncode')
                require(type(last_code) is int and last_code == 7, 'actual nonzero command receipt differs')
            if case.fault == 'producer-stderr':
                last_code = receipt['commands'][-1].get('returncode')
                require(type(last_code) is int and last_code == 0
                        and (work / 'build-1/latex-1.stderr').read_bytes() == b'INERT PRODUCER DIAGNOSTIC\n',
                        'actual zero-status stderr precursor differs')
            if case.fault == 'repeat-pdf':
                require((work / 'build-1/prefix-mgw-mean.pdf').read_bytes() == pdf
                        and (work / 'build-2/prefix-mgw-mean.pdf').read_bytes() != pdf,
                        'second-build mismatch was not causal')
            if case.fault == 'source-bytes':
                require((root / (UNIT + 'EXPOSITION.current.md')).read_bytes()
                        == toy['files'][UNIT + 'EXPOSITION.current.md'].encode() + b'\n',
                        'source byte mutation did not occur')
            if case.fault == 'source-mode':
                require(stat.S_IMODE((root / (UNIT + 'EXPOSITION.current.md')).stat().st_mode) == 0o600,
                        'source mode mutation did not occur')
            if case.fault in ('selector-before', 'selector-after'):
                require((binary / 'lualatex').resolve(strict=True)
                        == directory / 'tools/actual/alternate-lualatex-driver', 'selector mutation did not occur')
            if case.fault == 'tool-bytes':
                initial = strict_json((work / 'INPUTS.json').read_bytes())[str(binary / 'pandoc')]
                require(digest((binary / 'pandoc').read_bytes()) != initial['sha256'],
                        'tool byte mutation did not occur')
        for path, expected in protected.items():
            require(path.read_bytes() == expected, 'existing output bytes were overwritten')
        if case.mutation == 'work-existing':
            require((work / 'OWNED_MARKER').read_bytes() == b'preserve work marker\n', 'existing work changed')
        require(builder.read_bytes() == executed, 'entrypoint source changed; outer-owner rejection')
        execution.update(status='matched_expected_inert_entrypoint_behavior', name=case.name, mode=mode,
                         actual_tool_starts=len(started), actual_tool_completions=len(completed),
                         builder_receipt_sha256=digest(receipt_path.read_bytes()) if receipt is not None else None,
                         real_profile=case.real, no_real_production_or_proof_credit=True)
        return execution
    except BaseException as error:
        execution['failure'] = repr(error)
        raise
    finally:
        if process is not None and process.returncode is None:
            # Only the still-owned unreaped leader authorizes this kill.
            try:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=2)
            except BaseException as error:
                execution['cleanup_failure'] = repr(error)
        execution['completed_utc'] = dt.datetime.now(dt.timezone.utc).isoformat()
        for name in ('stdout.log', 'stderr.log', 'tool-trace.jsonl'):
            path = directory / name
            if path.is_file():
                raw = path.read_bytes(); execution[name] = {'bytes': len(raw), 'sha256': digest(raw)}
        keep(directory / 'CASE_RESULT.json', execution)


def main():
    require(os.name == 'posix' and sys.version_info >= (3, 11) and sys.flags.isolated and sys.flags.no_site
            and sys.dont_write_bytecode and sys.flags.optimize in (0, 1), 'requires Python 3.11+ -I -S -B, optional -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--registration', required=True, type=Path)
    parser.add_argument('--registration-sha256', required=True)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    registration_raw = source(args.registration)
    require(digest(registration_raw) == args.registration_sha256, 'control registration changed')
    registration = strict_json(registration_raw)
    require(type(registration) is dict
            and registration['schema'] == 'pid-rs/mean-pdf-builder-controls-execution-v1'
            and registration['status'] == 'reviewed_source_ready_for_inert_controls'
            and registration['builder_sha256'] == EXPECTED_BUILDER
            and type(registration['planned_cases']) is int and registration['planned_cases'] == 2 * len(CASES)
            and type(registration['harness_optimization']) is int
            and registration['harness_optimization'] == sys.flags.optimize
            and type(registration['new_PDF_productions']) is int and registration['new_PDF_productions'] == 0,
            'control registration scope differs')
    start, deadline = (dt.datetime.fromisoformat(registration[name]) for name in ('registered_utc', 'deadline_utc'))
    now = dt.datetime.now(dt.timezone.utc)
    require(start.tzinfo is not None and deadline.tzinfo is not None and start <= now < deadline
            and dt.timedelta(seconds=0) < deadline - start <= dt.timedelta(minutes=35), 'invalid registered control interval')
    output = args.output.absolute()
    require(output.parent == output.parent.resolve(strict=True) and '.local' in output.parts
            and not output.exists() and not output.is_symlink(), 'fresh canonical ignored output required')
    output.mkdir()
    keep(output / 'REGISTRATION.executed.json', registration_raw)
    result = {'status': 'failed', 'scope': 'inert full-entrypoint controls; no actual PDF production or theorem',
              'builder_sha256': EXPECTED_BUILDER, 'records': []}
    try:
        manifest_raw = source(LANE / 'SOURCE_MANIFEST.json')
        require(digest(manifest_raw) == registration['source_manifest_sha256'], 'control source manifest changed')
        sources = strict_json(manifest_raw)['files']
        for relative, expected in sources.items():
            require(digest(source(LANE / relative)) == expected, 'control source changed: ' + relative)
        builder_raw = source(LANE / 'inputs/real-profile/build-prefix-mgw-mean-pdf.py')
        require(digest(builder_raw) == EXPECTED_BUILDER, 'reviewed builder identity differs')
        require(digest(pin_values(builder_raw, {'MANIFEST_SHA': None, 'PDF_SHA': None})) == NORMALIZED_BUILDER,
                'builder differs beyond the two reviewed profile literals')
        tool_paths = {'python': Path(sys.executable).resolve(strict=True), 'shell': Path('/bin/sh').resolve(strict=True)}
        tool_bytes = {name: source(path) for name, path in tool_paths.items()}
        require(type(registration.get('tool_sha256')) is dict
                and set(registration['tool_sha256']) == set(tool_paths), 'execution tool registry differs')
        for name, raw in tool_bytes.items():
            require(registration['tool_sha256'][name] == digest(raw), 'execution tool digest differs: ' + name)
        keep(output / 'TOOLS.json', {name: {'path': str(tool_paths[name]), 'sha256': digest(raw), 'bytes': len(raw)}
                                     for name, raw in tool_bytes.items()})
        toy = strict_json(source(LANE / 'inputs/INERT_FIXTURES.json'))
        for mode in (0, 1):
            for case in CASES:
                require(dt.datetime.now(dt.timezone.utc) < deadline - dt.timedelta(seconds=20), 'control stage deadline before next case')
                directory = output / (str(len(result['records'])).zfill(3) + '-' + str(mode) + '-' + case.name)
                directory.mkdir()
                result['records'].append(run_case(directory, case, mode, builder_raw, toy, deadline))
        for relative, expected in sources.items():
            require(digest(source(LANE / relative)) == expected, 'control source changed after execution: ' + relative)
        require(all(source(tool_paths[name]) == raw for name, raw in tool_bytes.items()),
                'execution interpreter or shell changed during controls')
        require(len(result['records']) == 2 * len(CASES), 'incomplete control matrix')
        require(dt.datetime.now(dt.timezone.utc) < deadline, 'late control completion')
        result.update(status='all_registered_inert_entrypoint_cases_matched', cases=len(result['records']),
                      new_PDF_productions=0, new_proofs=0)
    except BaseException as error:
        result['failure'] = repr(error)
    finally:
        result['completed_utc'] = dt.datetime.now(dt.timezone.utc).isoformat()
        if dt.datetime.now(dt.timezone.utc) >= deadline:
            result.update(status='failed', closure_failure='original control deadline reached')
        keep(output / 'RESULT.json', result)
    print(json.dumps({'status': result['status'], 'completed_cases': len(result['records']),
                      'result': str(output / 'RESULT.json')}, sort_keys=True))
    return 0 if result['status'] == 'all_registered_inert_entrypoint_cases_matched' else 1


if __name__ == '__main__':
    raise SystemExit(main())
