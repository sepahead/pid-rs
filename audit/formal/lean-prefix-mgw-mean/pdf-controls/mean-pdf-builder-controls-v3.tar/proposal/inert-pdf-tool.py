#!/usr/bin/env python3
"""Bounded inert executable selected by whole-entrypoint PDF controls.

Does not run Pandoc, TeX, a PDF parser, or a log acceptance checker.
"""
from __future__ import annotations
import base64
import json
import os
from pathlib import Path
import sys
import time


def require(ok, message):
    if not ok:
        raise RuntimeError('inert tool fixture: ' + message)


def main():
    require(sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode,
            'Python flags differ')
    selector, plan_name, *argv = sys.argv[1:]
    plan_path = Path(plan_name)
    plan = json.loads(plan_path.read_bytes())
    require(plan['schema'] == 'pid-rs/mean-pdf-inert-tool-plan-v1', 'wrong plan')
    role = Path(selector).name
    require(role in ('pandoc', 'lualatex', 'bash'), 'selected executable name was lost')
    case = plan_path.parent
    fault = plan['fault']
    cwd = Path.cwd()
    row = {'role': role, 'selector': selector, 'argv': argv, 'cwd': str(cwd),
           'pid': os.getpid(), 'event': 'started'}

    def trace(value):
        descriptor = os.open(case / 'tool-trace.jsonl', os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o644)
        try:
            os.write(descriptor, (json.dumps(value, sort_keys=True) + '\n').encode())
        finally:
            os.close(descriptor)

    def finish(code=0):
        trace({**row, 'event': 'completed', 'returncode': code})
        return code

    def swap_selector():
        selected = Path(plan['lualatex_selector'])
        require(selected.is_symlink(), 'selector-change fixture is not a symlink')
        selected.unlink()
        selected.symlink_to(plan['alternate_lualatex_target'])

    trace(row)
    if role == 'pandoc' and argv == ['--version']:
        print('pandoc 0.0.0' if fault == 'pandoc-version' else 'pandoc 3.10.2')
        if fault == 'selector-before':
            swap_selector()
        return finish()
    if role == 'lualatex' and argv == ['--version']:
        print('wrong LuaLaTeX' if fault == 'lualatex-version'
              else 'This is LuaHBTeX, Version 1.18.0 (TeX Live 2024)')
        return finish()
    if role == 'pandoc':
        require(argv == ['--from=markdown', '--to=latex', '--shift-heading-level-by=-1',
                         '--wrap=none', '--output=body.tex', 'body.md'], 'Pandoc argv differs')
        require((cwd / 'body.md').read_bytes() == base64.b64decode(plan['body_markdown_b64']),
                'generated body Markdown differs from independent fixture literal')
        if fault == 'pandoc-nonzero':
            return finish(7)
        if fault == 'timeout':
            time.sleep(4.0)  # Only the private Pandoc producer has a two-second timeout.
        raw = base64.b64decode(plan['pandoc_raw_b64'])
        if fault == 'tex-sections':
            raw = raw.replace(b'\\section{9. Inert fixture}', b'\\subsection{9. Inert fixture}')
        elif fault == 'tex-heading':
            raw = raw.replace(b'7. A sensor with no target information can give a positive short-prefix mean',
                              b'7. Changed fixture heading')
        elif fault == 'tex-body':
            raw += b'% deliberate extra output\n'
        (cwd / 'body.tex').write_bytes(raw)
        return finish()
    if role == 'lualatex':
        require(argv == ['-no-shell-escape', '-interaction=nonstopmode', '-halt-on-error',
                         '-file-line-error', 'prefix-mgw-mean.tex'], 'LuaLaTeX argv differs')
        require((cwd / 'body.tex').read_bytes() == base64.b64decode(plan['body_latex_b64']),
                'generated TeX differs from independent fixture literal')
        if fault == 'lualatex-nonzero':
            return finish(7)
        pdf = base64.b64decode(plan['pdf_b64'])
        if fault == 'wrong-pdf' or (fault == 'repeat-pdf' and cwd.name == 'build-2'):
            pdf += b'INCORRECT SECOND OR FIRST OUTPUT\n'
        (cwd / 'prefix-mgw-mean.pdf').write_bytes(pdf)
        (cwd / 'prefix-mgw-mean.log').write_text('INERT CLEAN LOG\n')
        if fault == 'producer-stderr':
            print('INERT PRODUCER DIAGNOSTIC', file=sys.stderr)
        return finish()
    require(role == 'bash' and len(argv) == 2, 'log command shape differs')
    require(Path(argv[0]).name == 'check-formal-pdf-log.sh'
            and Path(argv[1]) == cwd / 'prefix-mgw-mean.log', 'log checker dispatch differs')
    require(Path(argv[0]).read_bytes() == base64.b64decode(plan['log_source_b64']),
            'inert log-checker source input differs')
    require(Path(argv[1]).read_text() == 'INERT CLEAN LOG\n', 'inert log input differs')
    if fault == 'log-nonzero':
        return finish(7)
    if fault == 'source-bytes':
        target = Path(plan['markdown_source'])
        target.write_bytes(target.read_bytes() + b'\n')
    elif fault == 'source-mode':
        Path(plan['markdown_source']).chmod(0o600)
    elif fault == 'tool-bytes':
        target = Path(plan['pandoc_selector'])
        target.write_bytes(target.read_bytes() + b'\n')
    elif fault == 'selector-after':
        swap_selector()
    return finish()


if __name__ == '__main__':
    raise SystemExit(main())
