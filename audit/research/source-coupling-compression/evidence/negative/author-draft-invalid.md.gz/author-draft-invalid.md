# Source partitions and information allocation under categorical recoding

**Sepehr Mahmoudian · 24 October 2026**

**Development draft.** This report gives a finite-law mathematical derivation and an exposed descriptive study. General probability formalization, production implementation of the new bounds, final publication review and accepted mainline publication remain open.

## Research question and main findings

An encoder can preserve everything needed to reconstruct an input tuple while changing what its individual coordinates mean. Does this preserve a partial information decomposition that names the original sources? If approximate preservation is sufficient, how can its error be bounded without using the target?

For the finite categorical shared-exclusions construction of Makkeh, Gutknecht and Wibral (MGW), the answer depends on **source partitions**: which observations each individual source treats as equal. A fixed deterministic recoding preserves every original-source atom for every finite target precisely when it preserves each source partition on the occupied support. Recovering the whole tuple is a weaker condition. An explicit example below preserves all joint prediction information yet moves a nonzero atom from one source to a redundancy shared by two sources.

The main derivation bounds the total absolute movement of the signed, averaged atoms by conditional entropies of the old and new sources under a common coupling. It applies to arbitrary finite coupled source changes, including stochastic changes, provided the target and original source positions remain the same. For three sources, the coalition weights are 22 for each singleton and pair, and 1 for the full triple. The proof needs no positivity assumption about the net atoms.

A completed study evaluates thirty overlapping empirical laws from two already exposed occupancy recordings. The new upper bound holds in all retained finite checks, but is too loose to establish a useful approximation on the nontrivial pooled laws. Office test data illustrate zero lost joint information with a changed allocation and improved average lookup-model loss. Room test data show lost information and worse loss. In the office example, lossless transport costs only three more reference-container bytes than lossy transport. These observations support careful separation of representation, prediction and attribution; they do not establish population or deployment benefit.

## Terms, symbols and scientific object

A **categorical variable** takes values in a finite alphabet. Its **occupied support** consists of values with positive probability. A variable induces a **partition** by grouping outcomes with equal values. An **empirical law** assigns each observed category its count divided by the number of rows. Evaluating that law is distinct from estimating an unknown population law.

**Partial information decomposition**, abbreviated PID, assigns information to positions representing different patterns of source sharing. Here the defining construction is MGW, *Introducing a differentiable measure of pointwise shared information*, [arXiv:2002.03356v5](https://arxiv.org/html/2002.03356v5), DOI [10.1103/PhysRevE.103.032149](https://doi.org/10.1103/PhysRevE.103.032149). Its informative and misinformative components have a signed difference called the **net** component. Negative net atoms are retained. This report does not use continuous Ehrlich PID, Williams–Beer minimum-information PID, or a general mixed-variable construction.

A **coupling** is one joint probability law containing both versions of the sources and the same target. **Variation of information** measures the uncertainty left in either partition when the other is known; this is a classical partition comparison, not a new measure introduced here. See [Meilă, *Comparing clusterings—an axiomatic view* (2005)](https://icml.cc/Conferences/2005/proceedings/papers/073_ComparingClustering_Meila.pdf). Entropy identities below are ordinary finite Shannon identities; see [Shannon (1948)](https://doi.org/10.1002/j.1538-7305.1948.tb01338.x).

| Symbol | Meaning |
|---|---|
| (r), ([r]) | Number of original sources; their index set, from 1 to (r) |
| (S,S'), (T) | Old and new source vectors, and the same target |
| (B), (S_B) | A nonempty set of source indices, and the tuple at those indices |
| (alpha,eta) | Families of source collections, called antichains, defined below |
| (G_eta), (C_eta) | Averaged event surprise and signed shared-information cumulative |
| (Pi_alpha) | Signed averaged atom at an original antichain position |
| (U_{alphaeta}) | Fixed integer matrix converting cumulatives into atoms |
| (H), (I), (operatorname{VI}) | Entropy, mutual information and variation of information |
| (D) | Sum of absolute old-minus-new net-atom changes |

All information quantities use natural logarithms and **nats**. Probabilities and categorical labels are dimensionless. Predictive log loss is in nats per evaluated row; Brier scores are dimensionless; serialized sizes are in bytes. A logarithm of a probability ratio is therefore dimensionally consistent.

For a finite variable (V), entropy and conditional entropy are

\[
H(V)=-\sum_{v:p(v)>0}p(v)\ln p(v),\qquad
H(V\mid W)=\sum_{w:p(w)>0}p(w)H(V\mid W=w).
\]

The inner entropy uses the conditional law at that (w). Null conditioning values are omitted. Mutual information is (I(V;T)=H(T)-H(T\mid V)). We use the chain rule (H(V,W)=H(W)+H(V\mid W)), nonnegativity of conditional entropy, and its decrease when additional variables are conditioned on. These facts apply to Shannon entropy; they do not imply monotonicity of signed PID atoms.

The mathematical results concern one arbitrary finite joint law (p(s,s',t)). Alphabets can differ before and after recoding, and unused labels are allowed. No Gaussian, independent-row, stationarity or positive-cell-floor assumption is required to evaluate the supplied law. None of those population or sampling properties is inferred from observed counts.

## The MGW event and the original source positions

A **source collection** is a nonempty subset of ([r]). An **antichain** is a nonempty family of collections in which no distinct member contains another. Let (mathcal A_r) be all such antichains. With three original sources there are eighteen positions. A notation such as ({{1},{2,3}}) has two branches: source 1 alone, or sources 2 and 3 together.

For any source vector (V) and supported value (v), the anchored event is

\[
E_\beta^V(v)=\bigcup_{B\in\beta}\{V_B=v_B\}.
\]

Equality of the tuple inside a branch requires agreement on **all** its indices; the union requires agreement on **at least one** branch. Thus the event uses AND within a branch and OR between branches. Constant sources remain original positions; the pair ((S_2,S_3)) may abbreviate a tuple but does not replace those positions with a new single source.

Define the unconditional and conditional event surprises by

\[
\begin{aligned}
G_\beta(V)&=\sum_v p(v)[-\ln p(E_\beta^V(v))],\\
G_\beta(V\mid T)&=\sum_{t:p(t)>0}p(t)
 \sum_v p(v\mid t)[-\ln p(E_\beta^V(v)\mid t)].
\end{aligned}
\]

Only positive-weight anchors enter the sums. At such an anchor its full source state belongs to every matching branch, so the event has positive probability. At a positive source–target anchor it also has positive conditional probability. All evaluated logarithms are finite, without assigning any value to an unsupported logarithm.

MGW's local net information is the logarithm of conditional event mass divided by unconditional event mass. Expanding this logarithm and averaging with the actual joint source–target weights gives

\[
C_\beta(V;T)=G_\beta(V)-G_\beta(V\mid T).
\]

This maps MGW v5 Equations (6)–(8), (15a)–(15b) and (17) to the present natural-log notation.

The order (alpha\preceq\beta) means that every branch of (eta) contains some branch of (alpha). MGW's finite inversion, Equation (13), is specified by

\[
C_\beta=\sum_{\alpha\preceq\beta}\Pi_\alpha,
\qquad
\Pi_\alpha=\sum_{\beta\in\mathcal A_r}U_{\alpha\beta}C_\beta.
\]

One can compute it by visiting lower nodes first and subtracting their already computed atoms from each cumulative. The resulting inverse matrix (U) has integer entries. Both evaluations below use this **same original carrier and same matrix**. The quantity of interest is

\[
D=\sum_{\alpha\in\mathcal A_r}
 |\Pi_\alpha(S;T)-\Pi_\alpha(S';T)|.
\]

It counts movement of the net atom vector only. Adding movements of informative, misinformative and net records would define a different quantity.

## A target-free bound from coupled source partitions

For each nonempty collection (B\subseteq[r]), put

\[
v_B=\operatorname{VI}(S_B,S'_B)
    =H(S'_B\mid S_B)+H(S_B\mid S'_B).
\]

These costs use the coupled source law. Define nonnegative integer coefficients

\[
c_\beta=\sum_{\alpha\in\mathcal A_r}|U_{\alpha\beta}|,
\qquad
w_B=\sum_{\beta:B\in\beta}c_\beta.
\]

The condition (B\in\beta) means that (B) is an actual branch of (eta), not merely a subset of one of its branches.

**Finite-law bound.** For one finite coupling of (S,S',T),

\[
\boxed{D\ \leq\ \sum_{\varnothing\ne B\subseteq[r]}w_Bv_B.}
\]

For three sources this becomes

\[
\boxed{D\ \leq\ 22\!\sum_{1\leq |B|\leq2}v_B+v_{\{1,2,3\}}
       \ \leq\ 67\sum_{i=1}^3\operatorname{VI}(S_i,S'_i).}
\]

The proof below is a written finite-probability derivation. It is not a completed probability formalization or a production API. No sharpness or scientific-priority claim is made.

### Step 1: compare nested unions

Consider finitely many events (C_j\subseteq D_j), indexed by (j=1,\ldots,m), with (p(C_j)>0). Write (c_j=p(C_j)), (d_j=p(D_j)), (c=p(\bigcup_jC_j)), and (d=p(\bigcup_jD_j)). The newly added part of the large union lies inside the union of the newly added branch parts. Consequently

\[
d-c\leq\sum_j(d_j-c_j).
\]

Since (c\geq c_j>0), division gives

\[
\frac dc\leq1+\sum_j\frac{d_j-c_j}{c}
 \leq1+\sum_j\left(\frac{d_j}{c_j}-1\right)
 \leq\prod_j\frac{d_j}{c_j}.
\]

For the last inequality, expand the product of (1+(d_j/c_j-1)). The constant and single-factor terms give the preceding expression; every remaining term is nonnegative. Taking logarithms yields

\[
0\leq\ln(d/c)\leq\sum_j\ln(d_j/c_j).
\]

Neither disjointness nor independence of the branches was used.

### Step 2: average a refinement increment

Suppose each coarse coordinate (A_i) is a deterministic function of a fine coordinate (V_i). At a supported fine anchor (v), let (a) be its coarse image. Apply Step 1 to (C_B=\{V_B=v_B\}) and (D_B=\{A_B=a_B\}) for the branches of (eta). The fine event is contained in the coarse event, so its surprise can only increase. The expected branch logarithm is

\[
\begin{aligned}
\mathbb E\ln\frac{p(A_B=a_B)}{p(V_B=v_B)}
 &=\sum_{v_B}p(v_B)[-\ln p(v_B\mid a_B)]\\
 &=H(V_B\mid A_B).
\end{aligned}
\]

The first equality uses that (a_B) is determined by (v_B). Summing over unused coordinates simply gives the marginal weight (p(v_B)). Averaging the union inequality therefore proves

\[
0\leq G_\beta(V)-G_\beta(A)
 \leq\sum_{B\in\beta}H(V_B\mid A_B).
\]

Repeat the same event argument inside each positive target stratum, then average those strata. This gives

\[
0\leq G_\beta(V\mid T)-G_\beta(A\mid T)
 \leq\sum_{B\in\beta}H(V_B\mid A_B,T)
 \leq\sum_{B\in\beta}H(V_B\mid A_B).
\]

The last inequality concerns conditional entropy, not the signed cumulative.

### Step 3: use one common refinement

At each original position set (W_i=(S_i,S'_i)). This gives (r) pair-valued sources, not (2r) source positions. Both old and new coordinates are deterministic projections of (W_i).

Let (a_\beta=\sum_{B\in\beta}H(S'_B\mid S_B)). Step 2 puts both (G_\beta(W)-G_\beta(S)) and (G_\beta(W\mid T)-G_\beta(S\mid T)) in the interval ([0,a_\beta]). Their difference has absolute value at most the length of this interval. Hence

\[
|C_\beta(W;T)-C_\beta(S;T)|\leq a_\beta.
\]

Interchanging old and new sources gives the corresponding bound with (\sum_{B\in\beta}H(S_B\mid S'_B)). Applying the triangle inequality through (W) gives

\[
|C_\beta(S;T)-C_\beta(S';T)|
 \leq q_\beta,\qquad q_\beta=\sum_{B\in\beta}v_B.
\]

There is no additional factor of two: two nonnegative increments within the same interval differ by at most its length. No informative- or misinformative-atom positivity theorem is used in this argument.

### Step 4: invert and regroup

Linearity of the unchanged finite inverse gives

\[
\begin{aligned}
|\Pi_\alpha(S;T)-\Pi_\alpha(S';T)|
 &\leq\sum_\beta|U_{\alpha\beta}|q_\beta,\\
D&\leq\sum_\beta c_\beta\sum_{B\in\beta}v_B
   =\sum_{B\ne\varnothing}w_Bv_B.
\end{aligned}
\]

Every sum is finite. The last equality only regroups each branch's occurrences. Signed atoms and cancellations are allowed; taking absolute values may make the bound conservative.

### Step 5: derive the three-source weights

For a node (eta), let (mathcal F_\beta) contain every nonempty source collection that contains a branch of (eta). This family is upward closed under set inclusion. Its minimal members are exactly the branches of (eta). The order reverses these families: (eta\preceq\alpha) exactly when (mathcal F_\alpha\subseteqmathcal F_\beta).

For a non-top node (eta), remove any subset (E) of its minimal members. The remaining family is still upward closed and nonempty: the full collection ([r]) remains. It therefore determines a unique upper node. The inverse-column entry at that node is ((-1)^{|E|}), with zero entries for all other removals. To check this claim, sum these proposed entries up to any upper node (alpha). The sum runs over subsets of the branches removed between (eta) and (alpha). At (alpha=eta), only the empty subset contributes, giving one. At a strict upper node, at least one minimal member must be removed: if a removed collection still contained a retained minimal member, upward closure would retain it. Pair each subset without that removed minimal member with the subset including it; their signs cancel. The sum is zero, precisely the inverse recurrence.

There are (2^{|\beta|}) subsets of the branches, each giving an inverse entry of absolute value one. Thus (c_\beta=2^{|\beta|}) except at the top node ({[r]}), where (c_\beta=1). The empty family is not a legal node and must not be counted.

For a fixed singleton, say ({1}), the nodes containing it as a branch are

\[
\{1\}\{2\}\{3\},\quad\{1\}\{2\},\quad\{1\}\{3\},
\quad\{1\}\{23\},\quad\{1\}.
\]

Here juxtaposed brace groups mean separate branches and (23) means ({2,3}). Their column sums are (8,4,4,4,2), totaling 22. For a fixed pair ({12}), the nodes are ({12}\{13\}\{23\}), ({12}\{13\}), ({12}\{23\}), ({3}\{12\}), and ({12}), with the same sums. The full triple is a branch only at the top, giving weight 1.

Finally the entropy chain rule, in any fixed order within (B), gives

\[
H(S'_B\mid S_B)
 =\sum_{i\in B}H(S'_i\mid S_B,\hbox{earlier primed coordinates})
 \leq\sum_{i\in B}H(S'_i\mid S_i).
\]

Apply the same argument in the reverse direction to obtain (v_B\leq\sum_{i\in B}v_{\{i\}}). Each of the three sources occurs in one singleton, two pairs and the full triple. Its coefficient is therefore (22+22+22+1=67), completing the proof.

### What the coupling premise excludes

The right side is target-free once the common coupling is supplied. It is not valid to choose a source-only coupling while ignoring the specified target margins. For example, let a uniform bit (T) equal (S), while (S') is an independent uniform bit. Their mutual informations with (T) differ. An artificial coupling (S'=S) has zero source cost but cannot also realize that independence from (T).

The theorem concerns averages. If a rare Bernoulli source equals the target and is replaced by a constant, its entropy tends to zero with the rare probability, while the local information at the rare outcome diverges. The averaged bound is not a uniform pointwise bound. A bound on the sum of informative and misinformative movements together would also need a different allowance.

## Exact invariance for every target

Fix a finite source law with occupied support (Omega), and a deterministic vector map (f) before choosing a target law. Write (S'=f(S)), retaining the original positions. The following are equivalent:

1. For every (i) and every (s,u\inOmega), (s_i=u_i) if and only if (f_i(s)=f_i(u)).
2. For every finite conditional target law (p(t\mid s)), all original averaged net atoms agree before and after applying (f).

The first condition says exactly that each new coordinate is a bijective relabeling of that individual old coordinate's occupied values. It is the known source-wise support-bijection premise discussed in [arXiv:2512.16662v2, Property 2 and Equation (3.2)](https://arxiv.org/html/2512.16662v2). Its use here and the following elementary converse carry no priority claim.

For sufficiency, the first condition preserves each coordinate equality, hence every branch conjunction and node union. Event masses, target-restricted masses and the averaging law agree at corresponding anchors. The local components, their inversions and their averages agree.

For necessity, a violated partition has one of two forms. If two positive-support states share (s_i) but have different (f_i(s)), choose the binary target (T=1[f_i(S)=f_i(s)]). The new coordinate determines (T), but the old one does not: the shared old value has positive probability of both target values. Thus its old conditional entropy of (T) is strictly positive, while its new one is zero. If two states have different (s_i) but share (f_i(s)), instead choose (T=1[S_i=s_i]). Now the old coordinate determines (T) and the new one does not. In either case the singleton mutual information changes. That mutual information is a fixed sum of original atoms, so all atoms cannot be equal. Binary targets already suffice.

A constant actual target makes every net atom zero even when partitions change. Equality for one target is therefore weaker than the universal statement. The converse also needs its deterministic-map premise; it is not asserted for arbitrary stochastic couplings. An empirical partition check certifies only the occupied empirical support, not unseen population states.

## Prediction loss, redistribution and lower certificates

Consider the study's deterministic map (S=(X,Y)) to (S'=(X,Y')), with (Y'=g(Y)). Here (X=S_1) and (Y=(S_2,S_3)) are tuple notation, while the PID still has three original positions. Define

\[
M=H(Y\mid X,Y'),\qquad
L=I(X,Y;T)-I(X,Y';T).
\]

Because (Y') is a function of (Y), inserting it into conditioning changes nothing when (Y) is already known. Therefore

\[
\begin{aligned}
L&=H(T\mid X,Y')-H(T\mid X,Y',Y)\\
 &=I(Y;T\mid X,Y')\\
 &=H(Y\mid X,Y')-H(Y\mid X,Y',T),
\end{aligned}
\]

so (0\leq L\leq M). Under a fully known law, conditional entropy is the best achievable expected logarithmic prediction loss. Thus (L) describes loss of ideal predictive information. It does not equal the change in a particular trained model's loss.

A finite entropy is zero exactly for a point mass: each term (-p\ln p) is nonnegative and is positive for a probability strictly between zero and one. It follows that (M=0) exactly when each occupied ((X,Y')) context has a single possible original (Y). This is a target-free recoverability check. It preserves joint information for every target, but need not preserve the named source partitions.

For the atoms define (Delta_\alpha=\Pi_\alpha(S;T)-\Pi_\alpha(S';T)), and let (R=\sum_\alpha\max(-\Delta_\alpha,0)). Reconstruction gives (\sum_\alpha\Delta_\alpha=L). The sum of positive changes minus the sum of negative magnitudes is (L), while their sum is (D). Eliminating the positive sum gives

\[
D=L+2R.
\]

Here (L\geq0) uses the deterministic compression premise. The quantity (R) is project-defined accounting for compensating atom movement, not another PID or a claim that net atoms are nonnegative. If (L=0), all movement is redistribution and (D=2R).

For an arbitrary common coupling, let (L_B=I(S_B;T)-I(S'_B;T)) for each nonempty coalition (B), and let (L_{\rm all}) use all sources. These changes can be negative. At the node with sole branch (B), the event formula is ordinary mutual information. Hence the contributing atom changes sum to (L_B), and the complementary changes sum to (L_{\rm all}-L_B). Apply the triangle inequality separately to these two disjoint groups:

\[
\boxed{\max_{B\ne\varnothing}
 (|L_B|+|L_{\rm all}-L_B|)\ \leq D.}
\]

There are seven cuts for three sources. A certified lower endpoint exceeding a previously specified allocation tolerance can reject fidelity. A small lower endpoint cannot accept fidelity. With numerical enclosures, take the distance of each interval from zero, using zero if the interval contains zero, rather than applying absolute value to a rounded midpoint.

## Worked counterexample: recoverability without allocation invariance

Let (S_1=0), and use two occupied values of (Y=(S_2,S_3)): (01) with probability (\delta), and (11) with probability (1-\delta), where (0<\delta<1). Set (T=S_2). The fixed map keeps (00) and (11), and sends (01) and (10) to (00). Thus occupied (01) maps to (00), and occupied (11) stays (11). This map is injective on the occupied tuples, so (Y) is recovered from (Y'), and (M=L=0).

Define the binary entropy (h_2(\delta)=-\delta\ln\delta-(1-\delta)\ln(1-\delta)). Before recoding, source 2 equals (T) and source 3 is constant. A node event equals the target-match event precisely when every branch contains position 2; otherwise a constant-only branch makes the event certain. The informative cumulative is therefore (h_2(\delta)) times the incidence column for node ({{2}}). Finite inversion puts the only informative atom there.

After recoding, both sources 2 and 3 equal (T). A node event equals the target-match event precisely when every branch intersects ({2,3}). This is the incidence column for node ({{2},{3}}). Its sole informative atom is (h_2(\delta)). In both laws (T) determines every source, so conditional source events are certain and all misinformative cumulatives and atoms are zero. Therefore

\[
\Pi_{\{\{2\}\}}=h_2(\delta),\qquad
\Pi'_{\{\{2\},\{3\}\}}=h_2(\delta),\qquad
D=2h_2(\delta)>0.
\]

All other net atoms are zero. The source-3 mutual-information change is (-h_2(\delta)), so its lower cut equals (D). At (\delta=1/2), movement is (2\ln2) nats. Exact finite controls also covered (\delta=1/100) and (1/10000). The movement tends to zero with the tail probability; this does not contradict finite-alphabet continuity. It does refute a proposed bound of (D) by a constant times tuple-recovery entropy alone.

## Study design: two exposed occupancy recordings

The study asks whether one fixed tuple recoding offers a useful loss/size trade-off while preserving the original information allocation. It evaluates the complete declared selection, including constants and unfavorable cases. It has no application-specific utility threshold or superiority claim.

The [frozen protocol](../PROTOCOL.md) and [revisions 2](../PROTOCOL_REVISION_2.md), [3](../PROTOCOL_REVISION_3.md) and [4](../PROTOCOL_REVISION_4.md) retain the exact definitions and amendments. The topic and both recordings were exposed through earlier work. Chronological train, validation and test roles do not make this an untouched confirmation study.

| Recording | Physical inputs in original source order | Original target and chronology |
|---|---|---|
| [UCI 864 Room Occupancy Estimation](https://doi.org/10.24432/C5P605) | Light channel S1_Light; binary passive-infrared channels S6_PIR and S7_PIR | Occupancy count 0–3; train 22–25 Dec 2017, validation 26 Dec, test 10–11 Jan 2018 |
| [UCI 357 Occupancy Detection](https://doi.org/10.24432/C5X01N) | Light in lux, CO2 in ppm, temperature in degrees Celsius | Binary occupancy; train 2–8 Feb 2015, validation 9–10 Feb, test 11–18 Feb |

The room light channel is treated in its recorded numeric unit; no physical calibration is performed. PIR labels and occupancy labels are retained as provided. Time zones are unknown. The room recording contains seven observed dates and a calendar gap; they are preserved despite source prose describing four days. The office files are combined chronologically, so their provider filenames do not determine the study roles. The datasets are attributed under their stated CC BY 4.0 licenses. Labels have not received independent auditing here.

Continuous active channels are binarized at their exact represented-decimal lower training median, with a value encoded as 1 only when strictly above the threshold. The thresholds are room light 1; office Light 0, CO2 455, Temperature 20.745, in their respective recorded units. Evaluation rows do not fit thresholds. Native PIR inputs remain binary. Thus the estimand concerns the resulting categorical representation, not the original continuous readings.

The last two sources form (Y). The two most frequent complete training tuples are selected by count, with lexical ties. Both recordings select (00) and (11). Training tuple counts in order (00,01,10,11) are ((6060,225,360,376)) for room and ((3703,704,710,3677)) for office. The total map keeps (00,11) and sends (01,10) to (00). It remains fixed on every date and role, including unseen legal tuples. It still reads both input coordinates; no sensor is removed.

Every complete row contributes its original target and three source bits. Mapped collisions are summed. The unchanged ((X,T)) marginal and equality of moved tail fraction with total-variation distance are checked exactly from counts. Missing or malformed active values, illegal labels, duplicate timestamps, unexpected dates and empty roles are refusal conditions, not row-deletion rules.

There are seven room dates and seventeen office dates, plus three pooled roles per recording: **24 daily and 6 pooled laws**. These are thirty overlapping descriptions of **two recordings**, not thirty datasets or independent tests. There are no confidence intervals, significance tests, resamples or population claims.

Four lookup models are fitted separately on training counts: full sources, mapped sources, (X) alone, and target frequencies alone. For a context (c) and target class (t), the fixed Laplace-1 rule is

\[
\widehat q(t\mid c)=\frac{n_{\rm train}(c,t)+1}{n_{\rm train}(c)+m},
\]

where (m) is 4 for room and 2 for office. Unseen contexts predict uniformly. A fifth evaluation applies the unchanged full-source model to remapped input values. This distinguishes substitution into a fixed model from training a compressed model. These pseudocounts apply to predictors only; the empirical PID laws are unsmoothed. No model, threshold or hyperparameter is chosen from validation outcomes.

Three actual encoded-source containers are compared: fixed two-bit tuple labels, lossless tuple dictionaries, and the fixed two-head map. Each also stores (X) in one bit. Actual headers, codebooks, payloads and final padding count toward bytes. Targets, timestamps, original real-valued readings, shared software and acquisition costs are excluded. Lossless decoding restores the original three coordinates before their PID is evaluated; a dictionary label is not substituted as a new PID source.

## Results and practical interpretation

The normal report is an [index of the complete law files](../campaign-v3-normal/REPORT.json), not a self-contained table of outcomes. Its thirty referenced byte counts and SHA-256 values were verified before reading the laws for this report. All counts, class outcomes, exact products, rational enclosures and 108 semantic coordinate keys per law remain there. Each key holds a before/after pair: eighteen positions, cumulative/atom stages, and informative/misinformative/net components. This is 216 scalar values, not 108 different atoms. The [summary CSV](summary.csv) is a compact derived view; the indexed JSON retains the numerical evidence.

The six pooled outcomes below use rounded displays in nats. Class counts are ordered by target label. Exact zeros shown here are supported by exact product identities, not a decimal rounding threshold.

| Recording and role | Rows | Target class counts | Lost information (L) | Allocation movement (D) |
|---|---:|---|---:|---:|
| Room train | 7,021 | 5,414 / 459 / 655 / 493 | 0.097702 | 0.309875 |
| Room validation | 1,063 | 1,063 / 0 / 0 / 0 | 0 | 0 |
| Room test | 2,045 | 1,751 / 0 / 93 / 201 | 0.044689 | 0.341754 |
| Office train | 8,794 | 6,681 / 2,113 | 0.020949 | 0.421590 |
| Office validation | 2,014 | 1,426 / 588 | 0 | 1.336128 |
| Office test | 9,752 | 7,703 / 2,049 | 0 | 0.582280 |

The tail fractions for these rows are respectively (585/7021), 0, (92/2045), (707/4397), (549/1007), and (4783/9752). The large office test tail still has zero tuple-recovery entropy: tail mass alone does not measure lost information.

| Recording and role | Recovery entropy (M) | Coalition MI lower cut | Coalition VI upper bound | Coordinate VI upper bound |
|---|---:|---:|---:|---:|
| Room train | 0.273506 | 0.224412 | 26.956702 | 31.395161 |
| Room validation | 0 | 0 | 0 | 0 |
| Room test | 0.126042 | 0.210829 | 16.650180 | 20.848626 |
| Office train | 0.441563 | 0.136466 | 49.429024 | 60.825588 |
| Office validation | 0.370627 | 0.402366 | 43.983542 | 61.961404 |
| Office test | 0 | 0.291415 | 27.776867 | 46.428674 |

The two new upper columns were computed under a separately declared [post-study plan](../POST_STUDY_BOUND_PLAN.md), not the original campaign's acceptance predicate. All thirty laws passed that finite follow-up, including 2,700 node inequalities: five checks at each of eighteen nodes for each law. This checks the supplied laws and implementation relationships; it cannot prove the universal probability theorem.

A fair comparison also includes a much simpler **range bound**. MGW v5 Theorem IV.3 gives nonnegative informative and misinformative atoms. Each family's full sum is respectively (H(S)) and (H(S\mid T)). Since the absolute net atom is at most the sum of these two components, the triangle inequality gives

\[
D\leq H(S)+H(S\mid T)+H(S')+H(S'\mid T)
 \leq 2[H(S)+H(S')].
\]

This is a composition of the published positivity result, not a new primary theorem. It uses positivity for that separate baseline; the coupled-source proof above does not. For three binary sources it is at most (4\ln8\), about 8.318 nats. Even this generic cap is smaller than the new coalition upper bounds on all five nonzero pooled cases. The coupling result supplies a meaningful zero endpoint and a general sensitivity statement, but these data do not show practical upper-bound tightness.

The frozen protocol also retains the earlier hand-derived total-variation comparison (130\min\{\ln8,\ d\ln(8/d)+8d\}), with value zero at (d=0); here (d) is the empirical total-variation distance. Its values and the range comparison remain separate in the summary and figures. No favorable upper bound is silently substituted for a failed scientific predicate.

![Allocation movement and comparison certificates on the six pooled empirical laws. The coalition cuts are lower bounds; the range, total-variation and coupled-source comparisons are upper bounds. Plotted numbers are rounded displays of retained rational enclosures, not population confidence intervals.](figures/allocation-comparison.pdf)

Average negative log probability for the frozen models is:

| Recording and role | Full sources | Compressed refit | Fixed-model remap | (X) only | Target only |
|---|---:|---:|---:|---:|---:|
| Room train | 0.438210 | 0.535497 | 0.557232 | 0.594131 | 0.786544 |
| Room validation | 0.057204 | 0.094076 | 0.057204 | 0.114754 | 0.260302 |
| Room test | 0.204922 | 0.258447 | 0.288580 | 0.320536 | 0.591635 |
| Office train | 0.114961 | 0.135559 | 0.150228 | 0.258339 | 0.551400 |
| Office validation | 0.090179 | 0.200645 | 0.335300 | 0.154282 | 0.610873 |
| Office test | 0.312825 | 0.267742 | 0.272705 | 0.270571 | 0.516683 |

Training-role values are fit-sample descriptions. All model losses use the same retained evaluation rows within a law. The Brier scores, paired changes, class losses and unseen-context counts are retained with the JSON rather than replaced by the average alone.

![Prediction comparison for the fixed training rules. Lower mean negative log probability is better on the evaluated rows. Compressed refitting and substitution into the unchanged full model are different arms; their displayed outcomes are descriptive and rounded.](figures/prediction-comparison.pdf)

Actual encoded-source container totals are:

| Recording and role | Fixed encoding, bytes | Lossless dictionary, bytes | Lossy map, bytes |
|---|---:|---:|---:|
| Room train | 2,921 | 2,924 | 2,032 |
| Room validation | 687 | 406 | 542 |
| Room test | 1,055 | 1,058 | 788 |
| Office train | 3,590 | 3,593 | 2,479 |
| Office validation | 1,048 | 1,045 | 784 |
| Office test | 3,949 | 2,721 | 2,718 |

### Office test: the recoding creates a virtual source copy

The seven occupied office test count rows all have the original CO2 **code** equal to 1. This says nothing about constancy of the physical CO2 reading. The only occupied ((\mathrm{CO2},\mathrm{Temperature})) bit tuples are (10) and (11). Mapping (10\mapsto00), (11\mapsto11) makes the new CO2 coordinate equal to the temperature coordinate. The map is invertible on these two occupied tuple types: their original values are recovered from the mapped values. Thus both (H(Y\mid Y')) and (M) are exactly zero.

The total joint information loss is zero, yet (D=0.5822795768) nats. Source partitions are preserved at positions 1 and 3 and changed at position 2. The source-2 mutual-information change is about (-0.1457076634) nats: its newly copied temperature bit now supplies target information. The resulting lower cut is 0.2914153267 nats. This is a change of coordinate attribution, not creation of new joint information or evidence of a causal sensor effect.

![Office test recoding on its occupied tuple types. The original CO2 bit is constant, while the mapped CO2 bit becomes a copy of the temperature bit. The complete tuple remains recoverable, but the original per-source equality partitions do not all remain the same.](figures/office-recoding.pdf)

Average compressed-refit loss improves from 0.3128245786 to 0.2677418095 nats per row, but occupied-class loss worsens from 0.1481131174 to 0.1885276919. There are 2,049 occupied-class rows. The favorable overall mean therefore does not establish uniform class benefit. The (X)-only model reaches 0.2705714743, providing a simple non-PID comparator near the compressed average.

A further design implication follows without a new benchmark. Let (G(x,g(y))) be the already fitted compressed model. Transmit (y) through the lossless dictionary, decode the exact original (y), and then apply the same map (g) and the same (G) at the receiver. Its probabilities and losses are mathematically identical to the measured compressed-refit arm, because its model inputs are identical row by row. Meanwhile the original coordinates remain available for attribution. All thirty lossless round trips were checked. For office test, this costs 2,721 rather than 2,718 bytes: the payload widths agree and the three-byte difference is in the reference headers. This separates the model choice from discarding the original representation. It is an offline implication for these containers, not a new deployed transport experiment or a novelty claim. The evaluation-stream dictionary includes its codebook cost; an online setting would need a separate design.

### Negative findings that determine the interpretation

Room test loses 0.0446885625 nats of joint information and moves 0.3417541442 nats across atoms. Refit log loss rises from 0.2049222659 to 0.2584466890, and Brier score rises from 0.1112679493 to 0.1393375394. Target class 1 is absent, so its class loss is unavailable. Classes 2 and 3 have only 93 and 201 rows; both have higher refit log loss than the full model. Their outcomes remain in the record.

Room validation has only target class 0 and no mapped tail. Its empirical atoms and (D,L,M) are all zero. Nonetheless refit loss is 0.0940763, worse than the full model's 0.0572038. The models learned different training tables even though the evaluation representation did not change. Exact empirical allocation invariance is therefore no guarantee about a separately fitted predictor.

Office validation also has zero joint information loss for its actual target, while (M=0.3706272) and (D=1.3361277). Its compressed-refit loss worsens from 0.0901786 to 0.2006450; the (X)-only model performs better than that refit. Retaining one target's joint information does not prove tuple recoverability or successful finite-sample learning. Lossless coding is smaller than lossy coding on room validation. None of these cases was removed to improve a summary.

## Exact arithmetic, controls and observed execution

At a positive source–target count cell (z), let (c_z) be its count, (N) the total count, (u_z) the node's source-event count, (v_z) its target-restricted count, and (t_z) the target count. They are positive at evaluated anchors. The local component terms are (ln(N/u_z)) and (ln(t_z/v_z)). Their count-weighted averages can be represented as (ln P/N), where (P) is a product of positive rational bases raised to integer counts. Integer inversion produces exact atom products. Product one establishes exact zero; product comparison establishes signs before absolute values are formed.

The numerical logarithm uses rational range reduction (x=2^k y), with integer (k) and (1\leq y<2). Put (z=(y-1)/(y+1)). The first 64 terms of

\[
\ln y=2\sum_{j=0}^{\infty}\frac{z^{2j+1}}{2j+1}
\]

have a nonnegative remainder at most (2z^{129}/[129(1-z^2)]). This follows by bounding all omitted denominators below by 129 and summing the remaining geometric series. The same construction at (z=1/3) encloses (ln2). Endpoints are rounded outward to denominator (2^{80}), with endpoint directions exchanged when multiplying by a negative coefficient. Required final widths are at most (10^{-12}) nats. These enclosures are arithmetic certificates for supplied laws, not statistical uncertainty intervals.

Three control attempts passed their respective frozen rosters. The final thirteen grouped checks include old/new candidate and reference agreement, constants and absent classes, original-carrier reconstruction, parity, zero tail, support creation, the recoverability counterexamples, and refusals or disagreements for wrong branch logic, reversed atom keys, collision loss, changed target or retained coordinates, wrong total-variation factor, malformed inputs and inadequate integer budgets. They are bounded controls, not a general mutation-completeness claim.

Two ordinary-mode campaigns reached their unchanged 180-second limit: the first completed 9 of 30 laws; the second completed 29. Both remain failed and spent, with their optimized counterparts unrun. Their sources and partial artifacts are retained. New versions refactored both exact implementations using prime-exponent cancellation before constructing rational products, without changing scientific quantities, precision, resource limits, inputs or acceptance predicates.

The third campaign completed all thirty laws in 22.29 seconds ordinarily and 22.19 seconds with Python optimization. Recorded Darwin process high-water memory was 80.4 MB and 82.9 MB, respectively, including process overhead rather than incremental algorithm allocation. These are pinned local executions of stock Python, not a controlled speedup comparison, production Rust timing, cross-platform benchmark or state-of-the-art result.

All 121 index, law and wire-container files match byte for byte across the two scheduled modes. All 29 completed second-campaign law files match their successful third-campaign successors. Time and memory receipts are separate and are not claimed byte-identical. The 6,645-byte common index has SHA-256 `ad0f9781265c7bdf3a9eadae04c063428e4507f946644d0cbbc42b240521bc2b`. Hashes identify retained bytes; they do not establish mathematical truth or external custody.

The installed stock Z3 5.3.1 route returned 46 unsatisfiable obligations and three satisfiable negative controls, and checked the actual finite matrix keys and integer weights. These 49 outcomes concern Boolean event correspondence and linear-real cut algebra. They do not formalize the logarithm, entropy or common-law probability proof. They are not execution of the repository's older 4.16 baseline. New Lean 4.33 deductive acceptance remains held; no global toolchain pin or kernel was changed for this work.

## Failed approaches and limits of transfer

The retained theory records explain why several attractive shortcuts fail:

- **Joint recoverability as an atom certificate:** the worked example has zero recovery entropy but nonzero movement. Reconsider only with individual partition preservation or a quantitative coupled-source bound.
- **Equal marginal laws:** old and new coordinates can have equal histograms while their relations to the target differ. Paired source information is needed.
- **Unqualified one-direction entropy:** mapping a target copy to a constant has zero entropy of the new source given the old, yet loses information. A directional theorem needs the appropriate coarsening premise and the entropy in the discarded direction.
- **Disagreement probability without alphabet control:** a variable can put mass (1-\epsilon) at zero and (\epsilon/n) at each of (n) rare labels. Its entropy is (h_2(\epsilon)+\epsilon\ln n). Sending everything to zero has disagreement probability (\epsilon), but unbounded information cost as (n) grows.
- **Concavity of event surprise:** for the two-source bottom event, let (a=00,b=01,c=11). A law equally supported on (a,c) has event surprise (ln2); a point mass at (b) has zero. Their equal mixture has masses (1/4,1/2,1/4) and event surprise (	frac12ln(4/3)<	frac12ln2). Ordinary entropy concavity cannot be imported into (G_\beta).

These are explicit rejected routes, not failures of the stated finite-law theorem. Their assumptions and reconsideration conditions remain in the [first coupling critique](../council-coupling-v1/FIRST.md) and [subsequent review](../council-coupling-v1/REVIEW.md). Small lower cuts do not accept fidelity; positive upper costs do not prove movement; allocation movement does not itself measure predictive harm. No result here supplies neural-model behavior, embodied or robotic performance, physical sensor removal, energy saving, causal utility, safety or online latency.

## Rust implementation and computational cost

The existing default-build Rust routes are `stable::categorical::discrete_sxpid2`, `discrete_sxpid3` and `discrete_sxpid_n`, with averaged, budgeted and cancellation variants in [sxpid.rs](../../../crates/pid-core/src/sxpid.rs). They support two to four categorical sources. Their empirical categorical estimand is distinct from the feature-gated continuous and mixed-dimensional research routes.

The new bounds and this exact study run through separate Python research sources: [candidate_v2.py](../candidate_v2.py), [exact_reference_v2.py](../exact-reference-v2/exact_reference_v2.py), [run_study_v3.py](../run_study_v3.py) and [post_study_bound.py](../post_study_bound.py). There is no new public Rust bound API, binding, production learner or paper-to-Rust refinement theorem. No Rust build or timing experiment was performed for this report.

For this workload, (N) is the row count and (Q) the number of occupied complete source–target cells. There are three binary sources, target alphabet size at most four, and (Q\leq32). Fitting medians uses (O(N\log N)) comparisons; transformation, count accumulation, lookup scoring and encoding then scan rows. A straightforward eighteen-node count reference takes (O(18\cdot3Q^2)) event-comparison work, before variable-size integer, rational-product and logarithm costs. Rows use (O(N)) storage, and the fixed support and atom tables are small. Prime factor cancellation reduces repeated large product construction, but its cost still depends on integer sizes.

Source partition checks and the seven coalition tables can be built directly from occupied paired states. Ordered counting adds logarithmic lookup costs; it must not be described as constant-time arithmetic. Those calculations can reject or bound a tolerance without evaluating all atoms, but actual end-to-end benefit over direct mutual information or task loss has not been measured. For general (r), the number of antichains grows rapidly; this theorem does not remove the output-size cost.

The research packet caps each recording at 32,768 rows, each law at 32 occupied cells, and exact product numerators and denominators at 1,048,576 bits. The output cap is 7.5 MiB per scheduled mode, with a 180-second campaign limit and five-second kill grace. Controls and the post-study check have separate 60-second limits. A malformed input, failed exact identity, unresolved required comparison, excessive interval width or resource exhaustion refuses that attempt. These process limits do not establish real-time suitability or a universal memory bound.

For the existing general Rust categorical engine, the inspected engineering baseline counts ((2m+1)Q^2) probability-table visits for (m) nodes, hence (37Q^2) for three sources, plus inversion and histogram work. This is a source-derived visit count, not the Python campaign's timing model. Rust's binary64 logarithms and resource/cancellation contracts are separate from the exact rational certificates here. Pointwise outputs retain more data than averaged outputs; cooperative cancellation and admission budgets are not hard latency guarantees.

Serialized lookup-count models use 229 versus 140 bytes for the room full/refit models and 192 versus 122 for office. Those figures exclude shared execution software and runtime state. No resampling, neural inference or physical actuation occurs. This is an offline diagnostic study; data dependence and population calibration remain separate from computational feasibility.

## Research process, provenance and remaining work

The decomposition itself is **paper-defined** MGW. Variation of information and source-wise bijective re-encoding are published concepts. The stability derivation, range-bound composition and coalition cuts are **paper-derived** consequences with their premises stated here. The total-movement statistic, redistribution accounting, frozen encoding, protocol, exact report schema and byte containers are **project-defined**. This work creates no implementation of a new PID functional and makes no scientific-priority claim. The bounded literature search is incomplete.

The recorded selection compared fourteen study routes, including no action, direct prediction loss, conditional mutual information, lossless coding, full original-carrier evaluation and alternative scientific objects. The proof council separately compared ten routes. The selected combination keeps simple comparators alongside the full allocation, and preserves rejected arguments. One map per recording and four fixed trained tables were used; there was no search for a favorable learner or a winning subset of laws. The three campaign versions concern exact implementation cost and output preservation, not selection of favorable scientific results.

AI agents proposed and criticized mathematics, authored separate exact calculations and assisted with reporting. First written critiques were frozen before exposure to other candidates; later reviews explicitly disclose their exposure. In particular, the universal-target converse and coefficient review include post-exposure reconstruction, and the independent reference refactor was exposed to the prime-cancellation idea and the timeout observations. The coordinating agent inspected sources and adjudicated the results. The councils use named hostile lenses as coverage checklists, not as independent people or votes that establish correctness.

The roles share model environment, host, definitions, paper sources, data exposure, ownership and custody. Independently authored code still shares stock integer/rational execution. Underlying model training-data exposure is unknown. No named human scientific-verification disposition, institutional independence, hidden confirmation set or deterministic hosted-model replay is asserted. The human byline records authorship and responsibility, not proof of independent review or priority.

The strongest present findings are the stated hand proof, exact counterexamples, scoped algebra outcomes and complete finite-law execution. The remaining edges are general probability formalization and qualified formal replay; source-to-executable and Rust correspondence; population estimation under temporal dependence; a useful application tolerance and cost contract; final semantic and visual publication review; and accepted durable publication. The wider categorical SxPID3 programs and repository-wide numerical, application and release goals remain open. Local completion of this report does not close them.

Suggested citation: **Sepehr Mahmoudian (2026), *Source partitions and information allocation under categorical recoding*.** Include the exact containing repository commit or release and the report identity when published. Cite [CITATION.cff](../../../CITATION.cff) separately for the software, the MGW paper for the functional, Meilă for variation of information, and the two UCI dataset records for the observations. This draft does not claim an accepted release or final publication.
